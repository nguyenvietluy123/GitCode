//
//  scrollView.swift
//  test
//
//  Created by Luy Nguyen on 5/24/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import NVActivityIndicatorView


class scrollView: UIViewController, UIScrollViewDelegate {

    @IBOutlet weak var scroll : UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scroll.delegate = self

    }
    func scrollViewDidScroll(_ scrollView: UIScrollView){
       print("\(scrollView.contentOffset.y)")
    }

    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool){
        
    }
    
   
}
