//
//  AuthVC.swift
//  test
//
//  Created by Luy Nguyen on 5/31/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class AuthVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        print("Xib file here")
    }


}
