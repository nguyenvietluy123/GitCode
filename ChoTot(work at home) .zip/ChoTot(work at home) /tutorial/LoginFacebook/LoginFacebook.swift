//
//  LoginFacebook.swift
//  test
//
//  Created by Luy Nguyen on 6/2/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import FBSDKLoginKit

class LoginFacebook: UIViewController {
    
    @IBOutlet weak var containerView: UIView!
    var customView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Login Facebook"
        
        let loginButton = FBSDKLoginButton()
        loginButton.center = self.containerView.center
        containerView.addSubview(loginButton)
            
        containerView.clipsToBounds = true
        customView = UIView(frame: CGRect(x: containerView.bounds.size.width/2 - 50, y: containerView.bounds.size.height/2 - 50, width: 100, height: 100))
        customView.backgroundColor = UIColor.red
        containerView.addSubview(customView)
    }
    
    
    
    @IBAction func removeXibFIle(_ sender: Any) {
        customView.removeFromSuperview()
    }
    
    

}
