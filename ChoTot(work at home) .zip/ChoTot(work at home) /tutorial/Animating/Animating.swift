//
//  Animating.swift
//  test
//
//  Created by Luy Nguyen on 5/28/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import NVActivityIndicatorView

class Animating: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(animating)
        animating.startAnimating()
        if animating.isAnimating {
            print("running")
        }else {
            print("fail")
        }
    }
    let animating = NVActivityIndicatorView(frame: CGRect(x: 0.0, y: 0.0, width: 420.0, height: 320.0), type: .ballBeat, color: UIColor.red, padding: CGFloat(24))
    
}
