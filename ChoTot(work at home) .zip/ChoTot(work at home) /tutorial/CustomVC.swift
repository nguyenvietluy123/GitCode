//
//  CustomVC.swift
//  test
//
//  Created by Luy Nguyen on 5/31/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class CustomVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let label = createLabel()
        view.addSubview(label)
        createButton()
 
    }

    private func createLabel() -> UILabel {
        let labelWidth: CGFloat = 300
        let labelHeight: CGFloat = 100
        
        let labelX = CGFloat(view.bounds.width / 2) - (labelWidth / 2)
        let labelY = CGFloat(view.bounds.height / 3)
        
        let labelFrame = CGRect(x: labelX, y: labelY, width: labelWidth, height: labelHeight)
        
        let label = UILabel(frame:  labelFrame)
        
        label.backgroundColor = UIColor.blue
        label.text = "Label here!"
        label.tintColor = UIColor.white
        label.textAlignment = .center
        
        return label
    }
    
    
    private func createButton() {
        let button = UIButton()
        
        button.setTitle("button here", for: .normal)
        button.backgroundColor = UIColor.brown
        button.tintColor = UIColor.white
        
        button.translatesAutoresizingMaskIntoConstraints = false
        
        let widthButton = NSLayoutConstraint(item: button, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 200)
        
        let heightButton = NSLayoutConstraint(item: button, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 70)
        
        let centerXButton = NSLayoutConstraint(item: button, attribute: .centerX, relatedBy: .equal, toItem: view, attribute: .centerX, multiplier: 1, constant: 0)
        
        let centerYButton = NSLayoutConstraint(item: button, attribute: .centerY, relatedBy: .equal, toItem: view, attribute: .centerY, multiplier: 1, constant: 0)
  
        view.addSubview(button)
        view.addConstraints([widthButton, heightButton, centerXButton, centerYButton])
    
        
        
        
    }
 
}
