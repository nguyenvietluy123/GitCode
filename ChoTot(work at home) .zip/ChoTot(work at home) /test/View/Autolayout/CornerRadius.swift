//
//  CornerRadius.swift
//  test
//
//  Created by Luy Nguyen on 6/3/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class CornerRadius: UIButton {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.cornerRadius = 5
        self.layer.masksToBounds = true
        self.layer.borderColor = UIColor.gray.cgColor
        self.layer.borderWidth = 1

    }
    
}
