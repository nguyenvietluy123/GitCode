//
//  RoundIcon.swift
//  test
//
//  Created by Luy Nguyen on 5/4/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class RoundIcon: UIImageView {

    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.cornerRadius = 41.5/2
        self.layer.masksToBounds = true
    }
}
