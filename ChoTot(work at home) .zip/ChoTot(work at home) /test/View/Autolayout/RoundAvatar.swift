//
//  RoundAvatar.swift
//  test
//
//  Created by Luy Nguyen on 5/3/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class RoundAvatar: UIImageView {

    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.cornerRadius = 97/2
        self.layer.masksToBounds = true
        self.layer.borderColor = UIColor.gray.cgColor
        self.layer.borderWidth = 3
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOffset = CGSize(width: 2, height: 10)
        self.layer.shadowRadius = 2
        self.layer.shadowOpacity = 0.5
    }

}
