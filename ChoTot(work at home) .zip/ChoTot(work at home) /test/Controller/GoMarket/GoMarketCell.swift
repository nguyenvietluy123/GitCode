//
//  GoMarketCell.swift
//  test
//
//  Created by Luy Nguyen on 5/8/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class GoMarketCell: UICollectionViewCell {
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    //    func setup(title: String, image: UIImage){
    //        titleName.text = title
    //        imageView.image = image
    //    }
    
    func  setup(_ item: inTroItem)  {
        labelTitle.text = item.titleName
        imageView.image = item.image
        
        
        labelTitle.numberOfLines = 0
        labelTitle.textColor = UIColor(white: 114 / 115, alpha: 5)
    }
    
    
}
