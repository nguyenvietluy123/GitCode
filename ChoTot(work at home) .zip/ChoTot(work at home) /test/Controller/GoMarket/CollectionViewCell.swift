//
//  CollectionViewCell.swift
//  test
//
//  Created by Luy Nguyen on 5/8/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
}
