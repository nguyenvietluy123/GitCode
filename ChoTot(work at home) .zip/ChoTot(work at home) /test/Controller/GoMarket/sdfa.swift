//
//  GoMarketVC.swift
//  test
//
//  Created by Luy Nguyen on 5/7/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//
import UIKit
enum inTroSize {
    case large
    case small
}

struct inTroItem {
    var titleName: String
    var image: UIImage
    var size: inTroSize = .small
}


class GoMarketVC: UIViewController, UISearchBarDelegate{
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    
    var arrayData = [inTroItem]()
    var filteredData = [String]()
    var isSearching: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let item  = inTroItem(titleName: "Bất động sản", image: #imageLiteral(resourceName: "icon_default_user"), size: .large)
        let item1 = inTroItem(titleName: "Bất động sản", image: #imageLiteral(resourceName: "icon_default_user"), size: .small)
        let item2 = inTroItem(titleName: "Bất động sản", image: #imageLiteral(resourceName: "icon_default_user"), size: .large)
        let item3 = inTroItem(titleName: "Bất động sản", image: #imageLiteral(resourceName: "icon_default_user"), size: .small)
        let item4 = inTroItem(titleName: "Bất động sản", image: #imageLiteral(resourceName: "icon_default_user"), size: .small)
        let item5 = inTroItem(titleName: "Bất động sản", image: #imageLiteral(resourceName: "icon_default_user"), size: .small)
        let item6 = inTroItem(titleName: "Bất động sản", image: #imageLiteral(resourceName: "icon_default_user"), size: .small)
        
        arrayData.append(item)
        arrayData.append(item1)
        arrayData.append(item2)
        arrayData.append(item3)
        arrayData.append(item4)
        arrayData.append(item5)
        arrayData.append(item6)
        
        collectionView.dataSource = self
        searchBar.delegate = self
        searchBar.returnKeyType = UIReturnKeyType.done
    }
}

extension GoMarketVC: UICollectionViewDataSource{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
}


//    func numberOfSections(in tableView: UITableView) -> Int {
//        return 1
//    }
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        if isSearching {
//            return filteredData.count
//        }
//        return data.count
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        if let cell = tableView.dequeueReusableCell(withIdentifier: "DataCell") as? DataCell {
//            let text: String!
//
//            if isSearching {
//                text = filteredData[indexPath.item]
//            }else{
//                text = data[indexPath.item]
//            }
//            cell.configureCell(text)
//
//            return cell
//        }else{
//            return UITableViewCell()
//        }
//    }
//
//    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//        if searchBar.text == nil || searchBar.text == "" {
//            isSearching = false
//            view.endEditing(true)
//            tableView.reloadData()
//        }else{
//            isSearching = true
//
//            filteredData = data.filter({$0 == searchBar.text})
//            tableView.reloadData()
//        }
//    }
//




