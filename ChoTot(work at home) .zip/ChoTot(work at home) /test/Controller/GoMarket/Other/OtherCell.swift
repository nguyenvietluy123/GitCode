//
//  OtherCell.swift
//  test
//
//  Created by Luy Nguyen on 7/8/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class OtherCell: UICollectionViewCell {    
    @IBOutlet weak var  img: UIImageView!
    @IBOutlet weak var title: UILabel!
    
    func setup(_ item: Kind){
        
        self.img.image = item.img
        self.title.text = item.title
    }
}
