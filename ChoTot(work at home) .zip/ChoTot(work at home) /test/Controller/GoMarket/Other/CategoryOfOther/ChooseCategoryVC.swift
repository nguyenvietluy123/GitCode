//
//  CategoryVC.swift
//  test
//
//  Created by Luy Nguyen on 7/1/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import RealmSwift

protocol ChooseCategoryDelegate: NSObjectProtocol {
    func selectRealEstate(_ string: String)
}
class ChooseCategoryVC: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    weak var delegateString: ChooseCategoryDelegate?
    
    var arrayCatalogue = [Catalogue]()
    var selectedCatalogue = [Catalogue]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createArray()
        
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func createArray() {
        let item = Catalogue()
        let item0 = Catalogue()
        let item1 = Catalogue()
        let item2 = Catalogue()
        let item3 = Catalogue()
        let item4 = Catalogue()
        let item5 = Catalogue()
        let item6 = Catalogue()
        let item7 = Catalogue()
        let item8 = Catalogue()
        let item9 = Catalogue()
        let item10 = Catalogue()
        let item11 = Catalogue()
        
        item.img = "black-house"
        item0.img = "black-scooter"
        item1.img = "black-building"
        item2.img = "black-monitor"
        item3.img = "black-baby-carriage"
        item4.img = "black-fashion"
        item5.img = "black-microwave-oven"
        item6.img = "black-gamepad"
        item7.img = "black-dog"
        item8.img = "black-office-supplies"
        item9.img = "black-job"
        item10.img = "black-briefcase"
        item11.img = "black-other"
        
        item.title = "Tất cả các mục"
        item0.title = "Xe cộ"
        item1.title = "Bất động sản"
        item2.title = "Đồ điện tử"
        item3.title = "Mẹ và bé"
        item4.title = "Thời trang, Đồ dùng cá nhân"
        item5.title = "Nội ngoại thất, Đồ gia dụng"
        item6.title = "Giải trí, Thể thao, Sở thích"
        item7.title = "Thú cưng"
        item8.title = "Đồ dùng văn phòng, công nông nghiệp"
        item9.title = "Việc làm"
        item10.title = "Dịch vụ, Du lịch"
        item11.title = "Các loại khác"
        
        arrayCatalogue += [item, item0, item1, item2, item3, item4, item5, item6, item7, item8, item9, item10, item11]
    }
    @IBAction func cancelButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    var passingString: String = ""
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let detailCategory = segue.destination as! DetailOfCategoryVC
        detailCategory.delegateString = self
        detailCategory.myCategory = passingString
    }
    
    
}

//----------------//----------------//----------------//----------------//----------------//

extension ChooseCategoryVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayCatalogue.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChooseCategoryCell") as! ChooseCategoryCell
        cell.setup(arrayCatalogue[indexPath.item])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        passingString = arrayCatalogue[indexPath.item].title
        if indexPath.item == 0 || indexPath.item == 2{
            self.delegateString?.selectRealEstate("\(self.arrayCatalogue[indexPath.item].title!)")
            self.dismiss(animated: true, completion: nil)
        }else {
            navigationItem.backBarButtonItem?.tintColor = UIColor.black
            performSegue(withIdentifier: "segue", sender: self)
        }
    }
}

extension ChooseCategoryVC: DetailOfCategoryDelegate {
    func selectDetailCategory(_ item: String) {
        self.delegateString?.selectRealEstate(item)
    }
    
    
}
