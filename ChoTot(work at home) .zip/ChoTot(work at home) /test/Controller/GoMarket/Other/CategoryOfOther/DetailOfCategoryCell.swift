//
//  CategoryCell.swift
//  test
//
//  Created by Luy Nguyen on 7/2/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit


class DetailCategoryCell: UITableViewCell {
    @IBOutlet weak var title: UILabel!
    
    func setup(_ item: String){
        self.title.text = item
    }


}
