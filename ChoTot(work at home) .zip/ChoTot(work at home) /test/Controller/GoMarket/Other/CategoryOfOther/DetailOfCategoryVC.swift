//
//  CategoryVC.swift
//  test
//
//  Created by Luy Nguyen on 7/1/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import RealmSwift

protocol DetailOfCategoryDelegate: NSObjectProtocol {
    func selectDetailCategory(_ item: String)
}
class DetailOfCategoryVC: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    var delegateString: DetailOfCategoryDelegate?
    
    var myCategory = String()
    let vehicleCategory = ["Tất cả xe cộ", "Ô tô", "Xe máy", "Xe tải, Xe khác", "Xe điện", "Xe đạp", "Phụ tùng xe"]
    let electricCategory = ["Tất cả đồ điện tử", "Điện thoại", "Máy tính bảng", "Laptop", "Máy tính để bàn", "Máy ảnh, Máy quay", "Tivi, Loa, Amply", "Màn hình, Phụ kiện"]
    let momAndBabyCategory = ["Tất cả mẹ và bé", "Mẹ và bé"]
    let fashionCategory = ["Tất cả thời trang, đồ dùng cá nhân", "Quần áo", "Đồng hồ", "Giày dép", "Túi xách", "Nước hoa", "Phụ kiện thời trang khác"]
    let housewareCategory = ["Tất cả nội ngoại thất, đồ gia dụng", "Tủ lạnh, Máy lạnh, Máy giặt", "Nội ngoại thất, Cây cảnh", "Đồ gia dụng gia đình khác"]
    let entertainmentCategory = ["Tất cả giải trí, thể thao, sở thích", "Âm nhạc, Phim, Sách", "Đồ thể thao, Dã ngoại", "Sưu tầm, Game, Sở thích khác"]
    let petCategory = ["Tất cả thú cưng", "Gà", "Chó", "Chim", "Thú cưng khác, Phụ kiện"]
    let officeCategory = ["Tất cả đồ dùng văn phòng, công nông nghiệp", "Đồ dùng văn phòng", "Đồ chuyên dụng, Giống nuôi trồng"]
    let jobCategory = ["Tất cả việc làm", "Việc tìm người", "Người tìm việc"]
    let travelCategory = ["Tất cả dịch vụ, du lịch", "Dịch vụ", "Du lịch"]
    let otherCategory = ["Tất cả các loại khác", "Các loại khác"]

    override func viewDidLoad() {
        super.viewDidLoad()
//        checkHistory()

        tableView.delegate = self
        tableView.dataSource = self
    }

}

extension DetailOfCategoryVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch myCategory {
        case "Xe cộ":
            return vehicleCategory.count
        case "Đồ điện tử":
            return electricCategory.count
        case "Mẹ và bé":
            return momAndBabyCategory.count
        case "Thời trang, Đồ dùng cá nhân":
            return fashionCategory.count
        case "Nội ngoại thất, Đồ gia dụng":
            return housewareCategory.count
        case "Giải trí, Thể thao, Sở thích":
            return entertainmentCategory.count
        case "Thú cưng":
            return petCategory.count
        case "Đồ dùng văn phòng, công nông nghiệp":
            return officeCategory.count
        case "Việc làm":
            return jobCategory.count
        case "Dịch vụ, Du lịch":
            return travelCategory.count
        default:
            return otherCategory.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailCategoryCell") as! DetailCategoryCell
        switch myCategory {
        case "Xe cộ":
            cell.setup(vehicleCategory[indexPath.item])
        case "Đồ điện tử":
            cell.setup(electricCategory[indexPath.item])
        case "Mẹ và bé":
            cell.setup(momAndBabyCategory[indexPath.item])
        case "Thời trang, Đồ dùng cá nhân":
            cell.setup(fashionCategory[indexPath.item])
        case "Nội ngoại thất, Đồ gia dụng":
            cell.setup(housewareCategory[indexPath.item])
        case "Giải trí, Thể thao, Sở thích":
            cell.setup(entertainmentCategory[indexPath.item])
        case "Thú cưng":
            cell.setup(petCategory[indexPath.item])
        case "Đồ dùng văn phòng, công nông nghiệp":
            cell.setup(officeCategory[indexPath.item])
        case "Việc làm":
            cell.setup(jobCategory[indexPath.item])
        case "Dịch vụ, Du lịch":
            cell.setup(travelCategory[indexPath.item])
        default:
            cell.setup(otherCategory[indexPath.item])
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch myCategory {
        case "Xe cộ":
            self.delegateString?.selectDetailCategory(vehicleCategory[indexPath.item])
        case "Đồ điện tử":
            self.delegateString?.selectDetailCategory(electricCategory[indexPath.item])
        case "Mẹ và bé":
            self.delegateString?.selectDetailCategory(momAndBabyCategory[indexPath.item])
        case "Thời trang, Đồ dùng cá nhân":
            self.delegateString?.selectDetailCategory(fashionCategory[indexPath.item])
        case "Nội ngoại thất, Đồ gia dụng":
            self.delegateString?.selectDetailCategory(housewareCategory[indexPath.item])
        case "Giải trí, Thể thao, Sở thích":
            self.delegateString?.selectDetailCategory(entertainmentCategory[indexPath.item])
        case "Thú cưng":
            self.delegateString?.selectDetailCategory(petCategory[indexPath.item])
        case "Đồ dùng văn phòng, công nông nghiệp":
            self.delegateString?.selectDetailCategory(officeCategory[indexPath.item])
        case "Việc làm":
            self.delegateString?.selectDetailCategory(jobCategory[indexPath.item])
        case "Dịch vụ, Du lịch":
            self.delegateString?.selectDetailCategory(travelCategory[indexPath.item])
        default:
            self.delegateString?.selectDetailCategory(otherCategory[indexPath.item])
        }
        self.dismiss(animated: true, completion: nil)
    }
}
