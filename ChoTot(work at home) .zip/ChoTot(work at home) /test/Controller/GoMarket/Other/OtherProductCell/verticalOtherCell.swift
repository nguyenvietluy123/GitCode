//
//  verticalForRentCell.swift
//  test
//
//  Created by Luy Nguyen on 6/25/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class verticalOtherCell: UITableViewCell {
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var imgImage: UIImageView!
    @IBOutlet weak var priceLabel : UILabel!
    @IBOutlet weak var statusLabel : UILabel!
    @IBOutlet weak var addressLabel : UILabel!
    
    func setup(_ item: FireBaseProduct){
        self.titleLabel.text = String(item.title)
        self.statusLabel.text = String(item.status)
        self.addressLabel.text = String(item.address)
        
        let getPrice = Int(item.price)
        let myIntString = getPrice.formattedWithSeparator
        self.priceLabel.text = myIntString
        
        let url: URL = URL(string: item.image)!
        imgImage.sd_setImage(with: url, completed: nil)
    }

}
