//
//  horizontalForRentCell.swift
//  test
//
//  Created by Luy Nguyen on 6/25/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class horizontalOtherCell: UICollectionViewCell {
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var labelPrice: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    
    func setup(_ item: FireBaseProduct){
        self.labelTitle.text = String(item.title)
        
        let getPrice = Int(item.price)
        let myIntString = getPrice.formattedWithSeparator
        self.labelPrice.text = myIntString
        
        let url: URL = URL(string: item.image)!
        imageView.sd_setImage(with: url, completed: nil)

        labelTitle.numberOfLines = 0
        labelTitle.textColor = UIColor.black
    }
}
