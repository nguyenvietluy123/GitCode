//
//  HousewareVC.swift
//  test
//
//  Created by Luy Nguyen on 6/7/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//
import UIKit
import Firebase
import FirebaseDatabase

class OtherVC: UIViewController, UISearchBarDelegate {
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var selectCategoryButton: UIButton!
    @IBOutlet weak var collectionViewCategory: UICollectionView!
    @IBOutlet weak var selectLocation: UIButton!
    @IBOutlet weak var viewForCategory: UIView!
    
    @IBOutlet weak var horizontalCollectionView: UICollectionView!
    @IBOutlet weak var heightViewForCategory: NSLayoutConstraint!
    @IBOutlet weak var view_Category_and_collectionView: UIView!
    

    var category: String? = ""
    
    var arrayHorizontalCell = [FireBaseProduct]()
    var arrayVerticalCell = [FireBaseProduct]()
    
    var housewareArray = [Kind(#imageLiteral(resourceName: "icon_refrigerator"), "Tủ lạnh, Máy lạnh, Máy giặt"), Kind(#imageLiteral(resourceName: "icon_sofa"), "Nội ngoại thất, Cây cảnh"), Kind(#imageLiteral(resourceName: "icon_rice_cooker"), "Đồ gia dụng gia đình khác")]
    var verhicalArray = [Kind(#imageLiteral(resourceName: "white_car"), "Ô tô"), Kind(#imageLiteral(resourceName: "white_motorbike"), "Xe máy"), Kind(#imageLiteral(resourceName: "white_truck"), "Xe tải, Xe khác"), Kind(#imageLiteral(resourceName: "white_electric_bicycle"), "Xe điện"), Kind(#imageLiteral(resourceName: "white_bicycle"), "Xe đạp"), Kind(#imageLiteral(resourceName: "white_spare_parts"), "Phụ tùng xe")]
    var carArray = [Kind(#imageLiteral(resourceName: "toyota"), "Toyota"), Kind(#imageLiteral(resourceName: "kia"), "Kia"), Kind(#imageLiteral(resourceName: "mazda"), "Mazda"), Kind(#imageLiteral(resourceName: "chevrolet"), "Chevrolet"), Kind(#imageLiteral(resourceName: "ford"), "Ford"), Kind(#imageLiteral(resourceName: "hyundai"), "Hyundai"), Kind(#imageLiteral(resourceName: "mercedes"), "Mercedes"), Kind(#imageLiteral(resourceName: "bmw"), "BMW"), Kind(#imageLiteral(resourceName: "another"), "Hãng khác") ]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        horizontalCollectionView.delegate = self
        horizontalCollectionView.dataSource = self
        tableView.delegate = self
        tableView.dataSource = self
        collectionViewCategory.delegate = self
        collectionViewCategory.dataSource = self
        
        var ref: DatabaseReference!
        ref = Database.database().reference()
        ref.child("SellHouse").observe(DataEventType.value) { (snapshot) in
            for data in snapshot.children{
                let product = FireBaseProduct(data as! DataSnapshot)
                self.arrayHorizontalCell.append(product)
                self.horizontalCollectionView.reloadData()
            }
        }

        ref.child("ForRent").observe(DataEventType.value) { (snapshot) in
            for data in snapshot.children {
                let product = FireBaseProduct(data as! DataSnapshot)
                self.arrayVerticalCell.append(product)
                self.tableView.reloadData()
            }
        }
        setNavigationOnTOp()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        if category != "Bất động sản"{
            selectCategoryButton.setTitle(category, for: .normal)
        }
        tableView.reloadData()
        collectionViewCategory.reloadData()
    }
    
    
    @IBAction func selectLocation(_ sender: Any) {
        let selectLocationStoryboard = UIStoryboard(name: "SelectLocation", bundle: nil)
        let selectLocationVC = selectLocationStoryboard.instantiateViewController(withIdentifier: SelectLocationVC.className) as! SelectLocationVC
        selectLocationVC.delegate = self
        let nav = UINavigationController(rootViewController: selectLocationVC)
        navigationController?.present(nav, animated: true, completion: nil)
    }
    
    @IBAction func selectCategory(_ sender: Any) {
        let productsStoryboard = UIStoryboard(name: "Products", bundle: nil)
        let chooseCategoryVC = productsStoryboard.instantiateViewController(withIdentifier: ChooseCategoryVC.className) as! ChooseCategoryVC
        chooseCategoryVC.delegateString = self
        let nav = UINavigationController(rootViewController: chooseCategoryVC)
        navigationController?.present(nav, animated: true, completion: nil)
    }
    
    func setNavigationOnTOp(){
        let searchBar = UISearchBar()
        searchBar.placeholder = "Tìm kiếm Nội ngoại thất, Đồ gia dụng"
        searchBar.barStyle = .black
        searchBar.delegate = self
        navigationItem.titleView = searchBar
        let button = UIButton()
        button.setImage(#imageLiteral(resourceName: "icon_bookmark_normal"), for: .normal)
        button.setImage(#imageLiteral(resourceName: "icon_bookmark_selected"), for: .selected)
        let rightBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "icon_bookmark_normal"), style: .plain, target: nil, action: nil)
        rightBarButtonItem.tintColor = UIColor.black
        navigationItem.rightBarButtonItem = rightBarButtonItem
    }
}

extension OtherVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == collectionViewCategory {
            switch category {
            case "Nội ngoại thất, Đồ gia dụng":
                return housewareArray.count
            case "Xe cộ", "Tất cả xe cộ":
                return verhicalArray.count
            case "Ô tô":
                return carArray.count
            default:
                return 1
            }
        } else {
            return arrayHorizontalCell.count
        }
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        collectionView.backgroundView = nil
        if collectionView == collectionViewCategory {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "OtherCell", for: indexPath) as! OtherCell
            switch category {
            case "Nội ngoại thất, Đồ gia dụng":
                cell.setup(housewareArray[indexPath.item])
            case "Xe cộ", "Tất cả xe cộ":
                let imgView = UIImageView(image: UIImage(named: "car"))
                imgView.frame = CGRect(x: 0, y: 0, width: viewForCategory.frame.size.width, height: viewForCategory.frame.size.height)
                imgView.alpha = 0.8
                collectionViewCategory.backgroundView = imgView
                cell.setup(verhicalArray[indexPath.item])
            case "Ô tô":
                cell.setup(carArray[indexPath.item])
            default:
                return cell
            }
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "horizontalOtherCell", for: indexPath) as! horizontalOtherCell
            cell.setup(arrayHorizontalCell[indexPath.item])
            return cell
        }
       
    }
    
}

extension OtherVC: SelectLocationDelegate, ChooseCategoryDelegate {
    func selectRealEstate(_ string: String) {
        category = string
        if category == "Bất động sản"{
            let productsStoryBoard = UIStoryboard.init(name: "Products", bundle: nil)
            let swipeMenuViewVC = productsStoryBoard.instantiateViewController(withIdentifier: SwipeMenuViewVC.className)
            
            navigationController?.navigationBar.tintColor = UIColor.black
            let backItem = UIBarButtonItem()
            backItem.title = ""
            navigationItem.backBarButtonItem = backItem
            self.navigationController?.pushViewController(swipeMenuViewVC, animated: true)
        }
        if category == "Tất cả các mục" {
            self.heightViewForCategory.constant = 0
            view_Category_and_collectionView.bounds = CGRect(x: 0, y: 0, width: view.frame.width, height: 136.5)
//            self.view_Category_and_collectionView.clipsToBounds = true

        }
    }
    
    func didSelectLocation(_ location: String) {
        selectLocation.titleLabel?.text = location
    }

}

