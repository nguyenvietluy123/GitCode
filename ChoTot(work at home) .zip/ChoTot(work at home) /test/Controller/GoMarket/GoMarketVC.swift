//
//  GoMarketVC.swift
//  test
//
//  Created by Luy Nguyen on 5/7/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//
import UIKit
import NVActivityIndicatorView
import Firebase

enum inTroSize {
    case large
    case small
}

struct inTroItem {
    var titleName: String
    var image: UIImage
    var size: inTroSize = .small
}


class GoMarketVC: UIViewController, UISearchBarDelegate, UICollectionViewDelegate{
    
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var floatButton: UIButton!
    @IBOutlet weak var buttonToBottomConstrainView: NSLayoutConstraint!
    @IBOutlet weak var titleLable: UILabel!
    
    let cellID = "GoMarketCell"
    var arrayData = [inTroItem]()
    var currentArray = [inTroItem]()

    override func viewDidLoad() {
        super.viewDidLoad()

        //collection view
        collectionView.dataSource = self
        collectionView.delegate = self
        
        //search bar
        searchBar.delegate = self
        searchBar.returnKeyType = UIReturnKeyType.done
        
        //function
        createSearchBar()
        appendToArrayData()
        customFloatButton()
        

        currentArray = arrayData
        collectionView.reloadData()
        
        settingNavigation()
    }
    

    
    func appendToArrayData() {
        let item  = inTroItem(titleName: "Bất động sản", image: #imageLiteral(resourceName: "photo_real_estate"), size: .large)
        let item1 = inTroItem(titleName: "Nội ngoại thất, Đồ gia dụng", image: #imageLiteral(resourceName: "photo_furniture"), size: .small)
        let item2 = inTroItem(titleName: "Xe cộ", image: #imageLiteral(resourceName: "photo_vehicle"), size: .large)
        let item3 = inTroItem(titleName: "Đồ điện tử", image: #imageLiteral(resourceName: "photo_iphone"), size: .small)
        let item4 = inTroItem(titleName: "Thời trang, Đồ dùng cá nhân", image: #imageLiteral(resourceName: "photo_watch"), size: .small)
        let item5 = inTroItem(titleName: "Mẹ và bé", image: #imageLiteral(resourceName: "photo_mom_and_baby"), size: .small)
        let item6 = inTroItem(titleName: "Thú cưng", image: #imageLiteral(resourceName: "photo_dog"), size: .small)
        let item7 = inTroItem(titleName: "Giải trí, Thể thao, Sở thích", image: #imageLiteral(resourceName: "photo_guitar"), size: .small)
        let item8 = inTroItem(titleName: "Đồ dùng văn phòng, công nông nghiệp", image: #imageLiteral(resourceName: "photo_fax"), size: .small)
        let item9 = inTroItem(titleName: "Việc làm, Dịch vụ", image: #imageLiteral(resourceName: "photo_job"), size: .small)
        let item10 = inTroItem(titleName: "Các loại khác", image: #imageLiteral(resourceName: "photo_candy"), size: .small)
        let item11 = inTroItem(titleName: "Tất cả các mục", image: #imageLiteral(resourceName: "photo_123"), size: .small)
        let item12 = inTroItem(titleName: "Cho tặng miễn phí", image: #imageLiteral(resourceName: "photo_gift"), size: .small)
        
        arrayData.append(item)
        arrayData.append(item1)
        arrayData.append(item2)
        arrayData.append(item3)
        arrayData.append(item4)
        arrayData.append(item5)
        arrayData.append(item6)
        arrayData.append(item7)
        arrayData.append(item8)
        arrayData.append(item9)
        arrayData.append(item10)
        arrayData.append(item11)
        arrayData.append(item12)
        
    }
    var passingData: String?
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier! == "OtherVC" {
            let otherVC = segue.destination as! OtherVC
            otherVC.category = passingData
        }
    }
    
    
    func createSearchBar(){
        let searchBar = UISearchBar()
        searchBar.placeholder = "Enter your searching!"
        searchBar.barStyle = .black
        searchBar.delegate = self
        self.navigationItem.titleView = searchBar
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else{
            currentArray = arrayData
            collectionView.reloadData()
            return
        }
        currentArray = arrayData.filter({ (item) -> Bool in
            item.titleName.lowercased().contains(searchText.lowercased())
        })
        collectionView.reloadData()
    }
    
    @IBAction func categoryButton(_ sender: Any) {
        let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let categoryVC = mainStoryboard.instantiateViewController(withIdentifier: "CategoryVC")
//        let nav = UINavigationController(rootViewController: categoryVC)
        self.navigationController?.pushViewController(categoryVC, animated: true)
    }
    func customFloatButton() {
//        self.view.removeConstraint(buttonToBottomConstrainView)
//        buttonToBottomConstrainView = NSLayoutConstraint(item: self.view, attribute: .bottom, relatedBy: .equal, toItem: floatButton, attribute: .bottom, multiplier: 1, constant: 100)
//        self.view.addConstraint(buttonToBottomConstrainView)
        floatButton.layer.cornerRadius = 24
        floatButton.layer.masksToBounds = true
    }

    var offSet: CGFloat = 0
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if offSet < collectionView.contentOffset.y || offSet > 70{
            UIView.animate(withDuration: 0.2, animations: {
                self.buttonToBottomConstrainView.constant = -100
                self.view.layoutIfNeeded()
            })
            offSet = collectionView.contentOffset.y
        }
        if offSet > collectionView.contentOffset.y || offSet < 70{
            UIView.animate(withDuration: 0.2, animations: {
                self.buttonToBottomConstrainView.constant = 7
                self.view.layoutIfNeeded()
            })
            offSet = collectionView.contentOffset.y
        }
    }

}

extension GoMarketVC: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return currentArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellID, for: indexPath) as! GoMarketCell
        cell.setup(currentArray[indexPath.item])
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath){
        switch indexPath.item {
        case 0:
            pushProductVC("SwipeMenuViewVC")
        default:
            passingData = arrayData[indexPath.item].titleName
            performSegue(withIdentifier: "OtherVC", sender: nil)
        }
    }
    func pushProductVC(_ category: String){
            let productsStoryBoard = UIStoryboard.init(name: "Products", bundle: nil)
            let add = productsStoryBoard.instantiateViewController(withIdentifier: "\(category)")
            navigationController?.pushViewController(add, animated: true)
    }
    
    func settingNavigation() {
        let backItem = UIBarButtonItem()
        backItem.title = ""
        navigationItem.backBarButtonItem = backItem
        navigationItem.backBarButtonItem?.tintColor = UIColor.black
   

    }
}

extension GoMarketVC: UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        
        let collectionSize = collectionView.frame.size
        var size = CGSize()
        size.width = 2
    
        if currentArray[indexPath.item].size == inTroSize.large{
            size.width = collectionSize.width * 2 / 3
            size.height = collectionSize.height/4 - 4
            return size
        }else{
            size.width = collectionSize.width / 3 - 3
            size.height = collectionSize.height/4 - 4
            return size
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat{
        return 2
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat{
        return 2
    }
}



