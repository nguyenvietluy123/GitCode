//
//  MuaBanVaChoThue.swift
//  test
//
//  Created by Luy Nguyen on 6/3/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class MuaBanVaChoThue: UIView {
    @IBOutlet var containView: UIView!
    @IBOutlet weak var selectLocation: UIButton!
    @IBOutlet weak var kindsOfLandscaping: UIButton!
    @IBOutlet weak var priceRange: UIButton!
    @IBOutlet weak var areaRange: UIButton!
    
    @IBOutlet weak var miniCount: CustomButton!
    
    var touchUpLocation: ((String) -> ())?
    var touchUpLandscaping: ((String) -> ())?
    var touchUpPriceRange: ((String) -> ())?
    var touchUpTotalArea: ((String) -> ())?
    var touchUpFilterResults: ((String) -> ())?
    //init tu frame
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    //init tu file xib
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed(MuaBanVaChoThue.className, owner: self, options: nil)
        addSubview(containView)
        containView.frame = self.bounds
        containView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        
    }
    
    @IBAction func selectLocation(_ sender: Any) {
        touchUpLocation?("String")
    }    
    @IBAction func selectKindsOfLandscaping(_ sender: Any) {
        touchUpLandscaping?("String")
    }
    @IBAction func choosePriceRange(_ sender: Any){
        touchUpPriceRange?("String")
    }
    @IBAction func chooseTotalArea(_ sender: Any){
        touchUpTotalArea?("String")
    }
    @IBAction func filterResults(_ sender: Any){
        touchUpFilterResults?("String")
    }
    
}

