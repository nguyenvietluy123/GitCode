//
//  CategoryVC.swift
//  test
//
//  Created by Luy Nguyen on 7/1/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import RealmSwift

class Catalogue: Object {
    @objc dynamic var img: String!
    @objc dynamic var title: String!
}
class Index: Object {
    @objc dynamic var index: Int = 0
}
class CategoryVC: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    var arrayCatalogue = [Catalogue]()
    var selectedCatalogue = [Catalogue]()

    override func viewDidLoad() {
        super.viewDidLoad()

        createArray()
        checkHistory()

        tableView.delegate = self
        tableView.dataSource = self
    }

    func createArray() {
        let item0 = Catalogue()
        let item1 = Catalogue()
        let item2 = Catalogue()
        let item3 = Catalogue()
        let item4 = Catalogue()
        let item5 = Catalogue()
        let item6 = Catalogue()
        let item7 = Catalogue()
        let item8 = Catalogue()
        let item9 = Catalogue()
        let item10 = Catalogue()
        let item11 = Catalogue()
        
        item0.img = "black-scooter"
        item1.img = "black-building"
        item2.img = "black-monitor"
        item3.img = "black-baby-carriage"
        item4.img = "black-fashion"
        item5.img = "black-microwave-oven"
        item6.img = "black-gamepad"
        item7.img = "black-dog"
        item8.img = "black-office-supplies"
        item9.img = "black-job"
        item10.img = "black-briefcase"
        item11.img = "black-other"
        
        item0.title = "Xe cộ"
        item1.title = "Bất động sản"
        item2.title = "Đồ điện tử"
        item3.title = "Mẹ và bé"
        item4.title = "Thời trang, Đồ dùng cá nhân"
        item5.title = "Nội ngoại thất, Đồ gia dụng"
        item6.title = "Giải trí, Thể thao, Sở Thích"
        item7.title = "Thú cưng"
        item8.title = "Đồ dùng văn phòng, công nông nghiệp"
        item9.title = "Việc làm"
        item10.title = "Dịch vụ, Du lịch"
        item11.title = "Các loại khác"
        
        arrayCatalogue += [item0, item1, item2, item3, item4, item5, item6, item7, item8, item9, item10, item11]
    }
    @IBAction func cancelButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func checkHistory() {
        let realm = try! Realm()
        let item = realm.objects(Catalogue.self)
        if item.count != 0 {
            alert()
        }else{
            print("continue")
        }
    }
    
    func alert() {
        let alert: UIAlertController = UIAlertController(title: "Tiếp tục với tin chưa viết xong", message: "Bạn có thể tiếp tục tin đang viết hoặc huỷ bỏ tạo một tin mới", preferredStyle: .alert)
        let continueButton: UIAlertAction = UIAlertAction(title: "Tiếp tục", style: .cancel) { (btn) in
            let realm = try! Realm()
            let item = realm.objects(Catalogue.self)
            self.selectedCatalogue = [item.last!]
            self.tableView.reloadData()
        }
        let newCreationButton: UIAlertAction = UIAlertAction(title: "Tạo mới", style: .default) { (btn) in
            self.selectedCatalogue.removeAll()
        }
        
        alert.addAction(continueButton)
        alert.addAction(newCreationButton)
        present(alert, animated: true, completion: nil)
    }
    

}

//----------------//----------------//----------------//----------------//----------------//

extension CategoryVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return selectedCatalogue.isEmpty == false ? 2 : 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if selectedCatalogue.isEmpty == false {
            if indexPath.section == 0 {
                return 60
            } else{
                let realm = try! Realm()
                let number = realm.objects(Index.self)
                if indexPath.item == number.last?.index {
                    return 0
                } else {
                    return 60
                }
            }
        }
        return 60
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if selectedCatalogue.isEmpty == false {
            if section == 0 {
                return 1
            }else{
                return arrayCatalogue.count
            }
        }
        return arrayCatalogue.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CategoryCell") as! CategoryCell
        cell.setup(arrayCatalogue[indexPath.item])
        
        if selectedCatalogue.isEmpty == false {
            if indexPath.section == 0 {
                cell.setup(selectedCatalogue[indexPath.item])
                cell.accessoryType = .checkmark
            } else if indexPath.section == 1 {
                cell.setup(arrayCatalogue[indexPath.item])
                cell.accessoryType = .disclosureIndicator
            }
        }
        return cell
   }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedCatalogue = [arrayCatalogue[indexPath.item]]
        
        let indexPathAt = Index()
        indexPathAt.index = indexPath.item
        
        let realm = try! Realm()
        try! realm.write {
            realm.add(selectedCatalogue)
            realm.add(indexPathAt)
            print("add \(selectedCatalogue)")
        }
        tableView.reloadData()

    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return selectedCatalogue.isEmpty == false ? 60 : 0
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if selectedCatalogue.isEmpty == false {
            if section == 0{
                return "Đã chọn"
            } else {
                return "Danh mục khác"
            }
        }
        return nil
    }
}
