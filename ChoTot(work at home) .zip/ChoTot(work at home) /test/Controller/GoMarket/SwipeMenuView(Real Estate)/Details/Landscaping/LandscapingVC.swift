//
//  LandscapingVC.swift
//  test
//
//  Created by Luy Nguyen on 6/10/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

protocol LandscapingDelegate: NSObjectProtocol {
    func didSelectLandscaping(_ landscaping: String)
}

class LandscapingVC: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    var arrayData: [String] = ["Tất cả", "Căn hộ/Chung cư", "Nhà ở", "Đất", "Văn phòng, Mặt bằng kinh doanh"]
    
    weak var delegate: LandscapingDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    @IBAction func cancelButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}

extension LandscapingVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "LandscapingCell") as! LandscapingCell
        cell.setup(arrayData[indexPath.item])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.item == 0 {
            self.delegate?.didSelectLandscaping("Tất cả các loại nhà đất")
        } else {
            let landscaping = arrayData[indexPath.item]
            self.delegate?.didSelectLandscaping(landscaping)
        }
        self.dismiss(animated: true, completion: nil)
    }
}


