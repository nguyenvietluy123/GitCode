//
//  HaNoiVC.swift
//  test
//
//  Created by Luy Nguyen on 6/9/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class HaNoiVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    var HaNoiLocation: [String] = ["Quận Hoàn Kiếm", "Quận Ba Đình", "Quận Đống Đa", "Quận Hai Bà Trưng", "Quận Thanh Xuân", "Quân Tây Hồ", "Quận Cầu Giấy", "Quận Hoàng Mai", "Quận Long Biên", "Huyện Đông Anh", "Huyện Sóc Sơn", "Huyện Thanh Trì", "Quận Hà Đông", "Thị Xã Sơn Tây"]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return HaNoiLocation.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HaNoiCell") as! HaNoiCell
        cell.setup(HaNoiLocation[indexPath.item])
        return cell
    }
    
    
}
