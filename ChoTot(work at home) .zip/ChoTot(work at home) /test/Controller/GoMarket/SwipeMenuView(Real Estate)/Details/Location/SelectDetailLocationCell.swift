//
//  SelectDetailLocationCell.swift
//  test
//
//  Created by Luy Nguyen on 6/9/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class SelectDetailLocationCell: UITableViewCell {

    @IBOutlet weak var labelTitle: UILabel!
    
    func setup(_ item: String){
        labelTitle.text = item
    }

}
