//
//  SelectDetailLocationVC.swift
//  test
//
//  Created by Luy Nguyen on 6/9/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

protocol SelectDetailLocationDelegate: NSObjectProtocol{
    func didSelectDetailLocation(_ location: String)
}

class SelectDetailLocationVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var tableView: UITableView!
    
    weak var delegate: SelectDetailLocationDelegate?
    
    let HaNoiLocation: [String] = ["Tất cả", "Quận Hoàn Kiếm", "Quận Ba Đình", "Quận Đống Đa", "Quận Hai Bà Trưng", "Quận Thanh Xuân", "Quân Tây Hồ", "Quận Cầu Giấy", "Quận Hoàng Mai", "Quận Long Biên", "Huyện Đông Anh", "Huyện Sóc Sơn", "Huyện Thanh Trì", "Quận Hà Đông", "Thị Xã Sơn Tây", "Huyện Đan Phượng", "Huyện Hoài Đức", "Huyện Quốc Oai", "Huyện Thạch Thất", "Huyện Chương Mỹ", "Huyện Thường Tín", "Huyện Phú Xuyên", "Quận Bắc Từ Liêm", "Quận Nam Từ Liêm", "Huyện Ba Vì", "Huyện Gia Lâm", "Huyện Mê Linh", "Huyện Mỹ Đức", "Huyện Phúc Thọ", "Huyện Thanh Oai", "Huyện Ứng Hoà", "Quận huyện khác"]
    let HoChiMinhLocation: [String] = ["Tất cả", "Quận 1", "Quận 2", "Quận 3", "Quận 4", "Quận 5", "Quận 6", "Quận 7", "Quận 8", "Quận 9", "Quận 10", "Quận 11", "Quận 12", "Quận Bình Tân", "Quận Bình Thạnh", "Quận Gò Vấp", "Quận Phú Nhuận", "Quận Tân Bình", "Quận Tân Phú", "Quận Thủ Đức", "Huyện Bình Chánh", "Huyện Củ Chi", "Huyện Hóc Môn", "Huyện Nhà Bè", "Huyện Cần Giờ", "Quận huyện khác"]
    let DongBacBoLocation: [String] = ["Tất cả", "Bắc Cạn", "Bắc Giang", "Cao Bằng", "Hà Giang", "Lạng Sơn", "Thái Nguyên", "Tuyên Quang", "Quảng Ninh", "Tỉnh khác"]
    let TayBacBoLocation: [String] = ["Tất cả", "Điện Biên", "Lai Châu", "Lào Cai", "Sơn La", "Yên Bái", "Tỉnh khác"]
    let CacTinhLanCanHaNoiLocation: [String] = ["Tất cả", "Bắc Ninh", "Phú Thọ", "Hà Nam", "Hải Dương", "Hoà Bình", "Hưng Yên", "Ninh Bình", "Vĩnh Phúc", "Tỉnh khác"]
    let HaiPhongNamDinhThaiBinhLocation: [String] = ["Tất cả", "Hải Phòng", "Nam Định", "Thái Bình", "Tỉnh khác"]
    let ThanhNgheTinhLocation: [String] = ["Tất cả", "Hà Tĩnh", "Nghệ An", "Thanh Hoá", "Tỉnh khác"]
    let BinhTriThuaThienHueLocation: [String] = ["Tất cả", "Quảng Bình", "Quảng Trị", "Thừa Thiên Huế", "Tỉnh khác"]
    let QuangNamDaNangLocation: [String] = ["Tất cả", "Quảng Nam", "Đà Nẵng", "Tỉnh khác"]
    let TayNguyenLocation: [String] = ["Tất cả", "Đắk Lắk", "Đắk Nông", "Kon Tum", "Gia Lai", "Lâm Đồng", "Tỉnh khác"]
    let NamTrungBoLocation: [String] = ["Tất cả", "Bình Thuận", "Bình Định", "Khánh Hoà", "Ninh Thuận", "Phú Yên", "Quảng Ngãi", "Tỉnh khác"]
    let DongNamBoLocation: [String] = ["Tất cả", "Bà Rịa Vũng Tàu", "Bình Dương", "Bình Phước", "Đồng Nai", "Tây Ninh", "Tỉnh khác"]
    let CanThoTayNamBoLocation: [String] = ["Tất cả", "An Giang", "Bạc Liêu", "Bến Tre", "Cần Thơ", "Cà Mau", "Đồng Tháp", "Hậu Giang", "Kiên Giang", "Long An", "Sóc Trăng", "Tiền Giang", "Trà Vinh", "Vĩnh Long", "Tỉnh khác"]
    
    //Array for Location in Project
    let HaiPhongLocation: [String] = ["Tất cả", "An Dương", "An Lão", "Bạch Long Vĩ", "Cát Hải", "Đồ Sơn", "Dương Kinh", "Hải An", "Hồng Bàng", "Kiến An", "Kiến Thuỵ", "Lê Chân", "Ngô Quyền", "Thuỷ Nguyên", "Tiên Lãng", "Vĩnh Bảo"]
    let DaNangLocation: [String] = ["Tất cả", "Cẩm Lệ", "Hải Châu", "Hoà Vang", "Hoàng Sa", "Liên Chiểu", "Ngũ Hành Sơn", "Sơn Trà", "Thanh Khê"]
    let CanThoLocation: [String] = ["Tất cả", "Bình Thuỷ", "Cái Răng", "Cờ Đỏ", "Ninh Kiều", "Ô Môn", "Phong Điền", "Thới Lai", "Thốt Nốt", "Vĩnh Thạnh"]
    let AnGiangLocation: [String] = ["Tất cả", "An Phú", "Châu Đốc", "Châu Phú", "Châu Thành", "Chợ Mới", "Long Xuyên", "Phú Tân", "Tân Châu", "Thoại Sơn", "Tịnh Biên", "Tri Tôn"]
    let BaRiaVungTauLocation: [String] = ["Tất cả","Bà Rịa", "Châu Đức", "Côn Đảo", "Đất Đỏ", "Long Điền", "Tân Thành", "Vũng Tàu", "Xuyên Mộc"]
    let BacGiangLocation: [String] = ["Tất cả", "Bắc Giang", "Hiệp Hoà", "Lạng Giang", "Lục Nam", "Lục Ngạn", "Sơn Động", "Tân Yên", "Việt Yên", "Yên Dũng", "Yên Thế"]
    let BacCanLocation: [String] = ["Tất cả", "Ba Bể", "Bắc Cạn", "Bạch Thông", "Chợ Đồn", "Chợ Mới", "Na Rì", "Ngân Sơn", "Pác Nặm"]
    let BacLieuLocation: [String] = ["Tất cả", "Bạc Liêu", "Đông Hải", "Giá Rai", "Hoà Bình", "Hồng Dân", "Phước Long", "Vĩnh Lợi"]
    let BacNinhLocation: [String] = ["Tất cả", "Bắc Ninh", "Gia Bình", "Lương Tài", "Quế Võ", "Thuận Thành", "Tiên Du", "Từ Sơn", "Yên Phong"]
    
    let BenTreLocation: [String] = ["Tất cả", "Ba Tri", "Bến Tre", "Bình Đại", "Châu Thành", "Chợ Lách", "Giồng Trôm", "Mỏ Cày Bắc", "Mỏ Cày Nam", "Thạnh Phú"]
    let BinhDinhLocation: [String] = ["Tất cả", "An Lão", "An Nhơn", "Hoài Ân", "Hoài Nhơn", "Phù Cát", "Phù Mỹ", "Quy Nhơn", "Tây Sơn", "Tuy Phuước", "Vân Canh", "Vĩnh Thạnh"]
    let BinhDuongLocation: [String] = ["Tất cả", "Bàu Bàng", "Bến Cát", "Dầu Tiếng", "Dĩ An", "Phú Giáo", "Tân Uyên", "Thủ Dầu Một", "Thuận An"]
    let BinhPhuocLocation: [String] = ["Tất cả", "Bình Long", "Bù Đăng", "Bù Đốp", "Bù Gia Mập", "Chơn Thành", "Đồng Phú", "Đồng Xoài", "Hớn Quản", "Lộc Ninh", "Phú Riềng", "Phước Long"]
    let BinhThuanLocation: [String] = ["Tất cả", "Bắc Bình", "Đảo Phú Quý", "Đức Linh", "Hàm Tân", "Hàm Thuận Bắc", "Hàm Thuận Nam", "La Gi", "Phan Thiết", "Tánh Linh", "Tuy Phong"]
    let CaMauLocation: [String] = ["Tất cả", "Cái Nước", "Đầm Dơi", "Năm Căn", "Ngọc Hiển", "Phú Tân", "Thới Bình", "Trần Văn Thời", "U Minh"]
    let CaoBangLocation: [String] = ["Tất cả", "Bảo Lạc", "Bảo Lâm", "Cao Bằng", "Hạ Lang", "Hà Quảng", "Hoà An", "Nguyên Bình", "Phục Hoà", "Quảng Uyên", "Thạch An", "Thông Nông", "Trà Lĩnh", "Trùng Khánh"]
    let DakLakLocation: [String] = ["Tất cả", "Buôn Đôn", "Buôn Hồ", "Buôn Ma Thuột", "Cư Kuin", "Cư M'gar", "Ea H'Leo", "Ea Kar", "Ea Súp", "Krông Ana", "Krông Bông", "Krông Buk", "Krông Năng", "Krông Pắc", "Lăk", "M'Đrăk"]
    let DakNongLocation: [String] = ["Tất cả", "Cư Jút", "Dăk Glong", "Dăk Mil", "Đăk R'lấp", "Dăk Song", "Gia Nghĩa", "Krông Nô", "Tuy Đức"]
    let DienBienLocation: [String] = ["Tất cả", "Điện Biên Đông", "Điện Biên Phủ", "Mường Ảng", "Mường Chà", "Mường Lay", "Mường Nhé", "Nậm Pồ", "Tủa Chùa", "Tuần Giáo"]
    let DongNaiLocation: [String] = ["Tất cả", "Biên Hoà", "Cẩm Mỹ", "Định Quán", "Long Khánh", "Long Thành", "Nhơn Trạch", "Tân Phú", "Thống Nhất", "Trảng Bom", "Vĩnh Cửu", "Xuân Lộc"]
    let DongThapLocation: [String] = ["Tất cả", "Cao Lãnh", "Châu Thành", "Hồng Ngự", "Huyện Cao Lãnh", "Huyện Hồng Ngự", "Lai Vung", "Lấp Vò", "Sa Đéc", "Tam Nông", "Tân Hồng", "Thanh Bình", "Tháp Mười"]
    let GiaLaiLocation: [String] = ["Tất cả", "An Khê", "AYun Pa", "Chư Păh", "Chư Pưh", "Chư Sê", "ChưPRông", "Đăk Đoa", "Đăk Pơ", "Đức Cư", "la Grai", "la Pa", "KBang", "Krông Chro", "Krông Pa", "Mang Yang", "Phú Thiện", "Plei Ku" ]
    let HaGiangLocation: [String] = ["Tất cả", "Bắc Mê", "Bắc Quang", "Đồng Văn", "Hà Giang", "Hoàng Su Phì", "Mèo Vạc", "Quản Bạ", "Quang Bình", "Vị Xuyên", "Xín Mần", "Yên Minh" ]
    let HaNamLocation: [String] = ["Tất cả", "Bình Lục", "Duy Tiên", "Kim Bảng", "Lý Nhân", "Phủ Lý", "Thanh Liêm"]
    let HaTinhLocation: [String] = ["Tất cả", "Cẩm XUyên", "Can Lộc", "Đức Thọ", "Hà Tĩnh", "Hồng Lĩnh", "Hương Khê", "Hương Sơn", "Kỳ Anh", "Lộc Hà", "Nghi Xuân", "Thạch Hà", "Vũ Quang"]
    let HaiDuongLocation: [String] = ["Tất cả", "Bình Giang", "Cẩm Giàng", "Chí Linh", "Gia Lộc", "Hải Dương", "Kim Thành", "Kinh Môn", "Nam Sách", "Ninh Giang", "Thanh Hà", "Thanh Miện", "Tứ Kỳ" ]
    let HauGiangLocation: [String] = ["Tất cả", "Châu Thành", "Châu Thành A", "Long Mỹ", "Ngã Bảy", "Phụng Hiệp", "Vị Thanh", "Vị Thuỷ"]
    let HoaBinhLocation: [String] = ["Tất cả", "Cao Phong", "Đà Bắc", "Hoà Bình", "Kim Bôi", "Kì Sơn", "Lạc Sơn", "Lạc Thuỷ", "Lương Sơn", "Mai Châu", "Tân Lạc", "Yên Thuỷ"]
    let HungYenLocation: [String] = ["Tất cả", "Ân Thi", "Hưng Yên", "Khoái Châu", "Kim Động", "Mỹ Hào", "Phù Cừ", "Tiên Lữ", "Văn Giang", "Văn Lâm", "Yên Mỹ"]
    let KhanhHoaLocation: [String] = ["Tất cả", "Cam Lâm", "Cam Ranh", "Diên Khánh", "Khánh Sơn", "Khánh Vĩnh", "Nha Trang", "Ninh Hoà", "Trường Sa", "Vạn Ninh"]
    let KienGiangLocation: [String] = ["Tất cả", "An Biên", "An Minh", "Châu Thành", "Giang Thành", "Giồng Riềng", "Gò Quao", "Hà Tiên", "Hòn Đất", "Kiên Hải", "Kiên Lương", "Phú Quốc", "Rạch Giá", "Tân Hiệp", "U Minh Thượng", "Vĩnh Thuận"]
    let KonTumLocation: [String] = ["Tất cả", "Đăk Glei", "Đăk Hà", "Đăk Tô", "la H'Drai", "Kon Plông", "Kon Rẫy", "KonTum", "Ngọc Hồi", "Sa Thầy", "Tu Mơ Rông"]
    let LaiChauLocation: [String] = ["Tất cả", "Lai Châu", "Mường Tè", "Nậm Nhùn", "Phong Thổ", "Sìn Hồ", "Tam Đường", "Tân Uyên", "Than Uyên"]
    let LamDongLocation: [String] = ["Tất cả", "Bảo Lâm", "Bảo Lộc", "Cát Tiên", "Đạ Huoai", "Đà Lạt", "Đạ Tẻh", "Đam Rông", "Di Linh", "Đơn Dương", "Đức Trọng", "Lạc Dương", "Lâm Hà" ]
    let LangSonLocation: [String] = ["Tất cả", "Bắc Sơn", "Bình Gia", "Cao Lộc", "Chi Lăng", "Đình Lập", "Hữu Lũng", "Lạng Sơn", "Lộc Bình", "Tràng Định", "Văn Lãng", "Văn Quan"]
    let LaoCaiLocation: [String] = ["Tất cả", "Bắc Hà", "Bảo Thắng", "Bảo Yên", "Bát Xát", "Lào Cai", "Mường Khương", "Sa Pa", "Văn Bàn", "Xi Ma Cai"]
    let LongAnLocation: [String] = ["Tất cả", "Bến Lức", "Cần Đước", "Cần Giuộc", "Châu Thành", "Đức Hoà", "Đức Huệ", "Kiến Tường", "Mộc Hoá", "Tân An", "Tân Hưng", "Tân Thạnh", "Tân Trụ", "Thạnh Hoá" , "Thủ Thừa", "Vĩnh Hưng"]
    let NamDinhLocation: [String] = ["Tất cả", "Giao Thuỷ", "Hải Hậu", "Mỹ Lộc", "Nam Định", "Nam Trực", "Nghĩa Hưng", "Trực Ninh", "Vụ Bản", "Xuân Trường", "Ý Yên"]
    let NgheAnLocation: [String] = ["Tất cả", "Anh Sơn", "Con Cuông", "Cửa Lò", "Diễn Châu", "Đô Lương", "Hoàng Mai", "Hưng Nguyên", "Kỳ Sơn", "Nam Đàn", "Nghi Lộc", "Nghĩa Đàn", "Quế Phong", "Quỳ Châu", "Quỳ Hợp", "Quỳnh Lưu", "Tân Kỳ", "Thái Hoà", "Thanh Chương", "Tương Dương", "Vinh", "Yên Thành"]
    let NinhBinhLocation: [String] = ["Tất cả", "Gia Viễn", "Hoa Lư", "Kim Sơn", "Nho Quan", "Ninh Bình", "Tam Điệp", "Yên Khánh", "Yên Mô"]
    let NinhThuanLocation: [String] = ["Tất cả", "Bắc Ái", "Ninh Hải", "Ninh Phước", "Ninh Sơn", "Phan Rang - Tháp Chàm", "Thuận Bắc", "Thuận Nam"]
    let PhuThoLocation: [String] = ["Tất cả", "Cẩm Khê", "Đoan Hùng", "Hạ Hoà", "Lâm Thao", "Phù Ninh", "Phú Thọ", "Tam Nông", "Tân Sơn", "Thanh Ba", "Thanh Sơn", "Thanh Thuỷ", "Việt Trì", "Yên Lập"]
    let PhuYenLocation: [String] = ["Tất cả", "Đông Hoà", "Đồng Xuân", "Phú Hoà", "Sơn Hoà", "Sông Cầu", "Sông Hinh", "Tây Hoà", "Tuy An", "Tuy Hoà"]
    let QuangBinhLocation: [String] = ["Tất cả", "Ba Đồn", "Bố Trạch", "Đồng Hới", "Lệ Thuỷ", "Minh Hoá", "Quảng Ninh", "Quảng Trịch", "Tuyên Hoá"]
    let QuangNamLocation: [String] = ["Tất cả", "Bắc Trà My", "Đại Lộc", "Điện Bàn", "Đông Giang", "Duy Xuyên", "Hiệp Đức", "Hội An", "Nam Giang", "Nam Trà My", "Nông Sơn", "Núi Thành", "Phú Ninh", "Phước Sơn", "Quế Sơn", "Tam Kỳ", "Tây Giang", "Thăng Bình", "Tiên Phước"]
    let QuangNgaiLocation: [String] = ["Tất cả", "Ba Tơ", "Bình Sơn", "Đức Phổ", "Lý Sơn", "Minh Long", "Mộ Đức", "Nghĩa Hành", "Quảng Ngãi", "Sơn Hà", "Sơn Tây", "Sơn Tịnh", "Tây Trà", "Trà Bồng", "Tư Nghĩa" ]
    let QuangNinhLocation: [String] = ["Tất cả", "Ba Chẽ", "Bình Liêu", "Cẩm Phả", "Cô Tô", "Đầm Hà", "Đông Triều", "Hạ Long", "Hải Hà", "Hoành Bồ", "Móng Cái", "Quảng Yên", "Tiên Yên", "Uông Bí", "Vân Đồn"]
    let QuangTriLocation: [String] = ["Tất cả", "Cam Lộ", "Đa Krông", "Đảo Cồn Cỏ", "Đông Hà", "Gio Linh", "Hải Lăng", "Hướng Hoá", "Quảng Trị", "Triệu Phong", "Vĩnh Linh"]
    let SocTrangLocation: [String] = ["Tất cả", "Châu Thành", "Cù Lao Dung", "Kế Sách", "Long Phú", "Mỹ Tú", "Mỹ Xuyên", "Ngã Năm", "Sóc Trăng", "Thạnh Trị", "Trần Đề", "Vĩnh Châu"]
    let SonLaLocation: [String] = ["Tất cả", "Bắc Yên", "Mai Sơn", "Mộc Châu", "Mường La", "Phù Yên", "Quỳnh Nhai", "Sơn La", "Sông Mã", "Sốp Cộp", "Thuận Châu", "Vân Hồ", "Yên Châu" ]
    let TayNinhLocation: [String] = ["Tất cả", "Bến Cầu", "Châu Thành", "Dương Minh Châu", "Gò Dầu", "Hoà Thành", "Tân Biên", "Tân Châu", "Tây Ninh", "Trảng Bàng"]
    let ThaiBinhLocation: [String] = ["Tất cả", "Đông Hưng", "Hưng Hà", "Kiến Xương", "Quỳnh Phụ", "Thái Bình", "Thái Thuỵ", "Tiền Hải", "Vũ Thư"]
    let ThaiNguyenLocation: [String] = ["Tất cả", "Đại Từ", "Định Hoá", "Đồng Hỷ", "Phổ Yên", "Phú Bình", "Phú Lương", "Sông Công", "Thái Nguyên", "Võ Nhai"]
    let ThanhHoaLocation: [String] = ["Tất cả", "Bá Thước", "Bỉm Sơn", "Cẩm Thuỷ", "Đông Sơn", "Hà Trung", "Hậu Lộc", "Hoằng Hoá", "Lang Chánh", "Mường Lát", "Nga Sơn", "Ngọc Lặc", "Như Thanh", "Như Xuân", "Nông Cống", "Quan Hoá", "Quan Sơn", "Quảng Xương", "Sầm Sơn", "Thạch Thành", "Thanh Hoá", "Thiệu Hoá", "Thọ Xuân", "Thường Xuân", "Tĩnh Gia", "Triệu Sơn", "Vĩnh Lộc", "Yên Định" ]
    let ThuaThienHueLocation: [String] = ["Tất cả", "A Lưới", "Huế", "Hương Thuỷ", "Hương Trà", "Nam Đông", "Phong Điền", "Phú Lộc", "Phú Vang", "Quảng Điền"]
    let TienGiangLocation: [String] = ["Tất cả", "Cái Bè", "Cai Lậy", "Châu Thành", "Chợ Gạo", "Gò Công", "Gò Công Đông", "Gò Công Tây", "Huyện Cai Lậy", "Mỹ Tho", "Tân Phú Đông", "Tân Phước" ]
    let TraVinhLocation: [String] = ["Tất cả", "Càng Long", "Cầu Kè", "Cầu Ngang", "Châu Thành", "Duyên Hải", "Tiểu Cần", "Trà Cú", "Trà Vinh"]
    let TuyenQuangLocation: [String] = ["Tất cả", "Chiêm Hoá", "Hàm Yên", "Lâm Bình", "Na Hang", "Sơn Dương", "Tuyên Quang", "Yên Sơn"]
    let VinhLongLocation: [String] = ["Tất cả", "Bình Minh", "Bình Tân", "Long Hồ", "Mang Thít", "Tam Bình", "Trà Ôn", "Vĩnh Long", "Vũng Liêm"]
    let VinhPhucLocation: [String] = ["Tất cả", "Bình Xuyên", "Lập Thạch", "Phúc Uyên", "Sông Lô", "Tam Đảo", "Tam Dương", "Vĩnh Tường", "Vĩnh Yên", "Yên Lạc"]
    let YenBaiLocation: [String] = ["Tất cả", "Lục Yên", "Mù Cang Chải", "Nghĩa Lộ", "Trạm Tấu", "Trấn Yên", "Văn Chấn", "Văn Yên", "Yên Bái", "Yên Bình"]
    
    
    override func viewDidLoad() {
        tableView.delegate = self
        tableView.dataSource = self

        }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.title == "Hà Nội" as String{
            return HaNoiLocation.count
        }
        if self.title == "Hồ Chí Minh" as String{
            return HoChiMinhLocation.count
        }
        if self.title == "Đông Bắc Bộ" as String{
            return DongBacBoLocation.count
        }
        if self.title == "Tây Bắc Bộ" as String{
            return TayBacBoLocation.count
        }
        if self.title == "Các tỉnh lân cận Hà Nội" as String{
            return CacTinhLanCanHaNoiLocation.count
        }
        if self.title == "Hải Phòng Nam Định Thái Bình" as String{
            return HaiPhongNamDinhThaiBinhLocation.count
        }
        if self.title == "Thanh Nghệ Tĩnh" as String{
            return ThanhNgheTinhLocation.count
        }
        if self.title == "Bình Trị Thừa Thiên Huế" as String{
            return BinhTriThuaThienHueLocation.count
        }
        if self.title == "Quảng Nam Đà Nẵng" as String{
            return QuangNamDaNangLocation.count
        }
        if self.title == "Tây Nguyên" as String{
            return TayNguyenLocation.count
        }
        if self.title == "Nam Trung Bộ" as String{
            return NamTrungBoLocation.count
        }
        if self.title == "Đông Nam Bộ" as String{
            return DongNamBoLocation.count
        }
        if self.title == "Cần Thơ - Tây Nam Bộ" as String{
            return CanThoTayNamBoLocation.count
        }
        if self.title == "Hải Phòng" as String{
            return HaiPhongLocation.count
        }
        if self.title == "Đà Nẵng" as String{
            return DaNangLocation.count
        }
        if self.title == "Cần Thơ" as String{
            return CanThoLocation.count
        }
        if self.title == "An Giang" as String{
            return AnGiangLocation.count
        }
        if self.title == "Bà Rịa Vùng Tàu" as String{
            return BaRiaVungTauLocation.count
        }
        if self.title == "Bắc Giang" as String{
            return BacGiangLocation.count
        }
        if self.title == "Bắc Cạn" as String{
            return BacCanLocation.count
        }
        if self.title == "Bạc Liêu" as String{
            return BacLieuLocation.count
        }
        if self.title == "Bắc Ninh" as String{
            return BacNinhLocation.count
        }
        if self.title == "Bến Tre" as String{
            return BenTreLocation.count
        }
        if self.title == "Bình Định" as String{
            return BinhDinhLocation.count
        }
        if self.title == "Bình Dương" as String{
            return BinhDuongLocation.count
        }
        if self.title == "Bình Phước" as String{
            return BinhPhuocLocation.count
        }
        if self.title == "Bình Thuận" as String{
            return BinhThuanLocation.count
        }
        if self.title == "Cà Mau" as String{
            return CaMauLocation.count
        }
        if self.title == "Cao Bằng" as String{
            return CaoBangLocation.count
        }
        if self.title == "Đắk Lắk" as String{
            return DakLakLocation.count
        }
        if self.title == "Đắc Nông" as String{
            return DakNongLocation.count
        }
        if self.title == "Điện Biên" as String{
            return DienBienLocation.count
        }
        if self.title == "Đồng Nai" as String{
            return DongNaiLocation.count
        }
        if self.title == "Đồng Tháp" as String{
            return DongThapLocation.count
        }
        if self.title == "Gia Lai" as String{
            return GiaLaiLocation.count
        }
        if self.title == "Hà Giang" as String{
            return HaGiangLocation.count
        }
        if self.title == "Hà Nam" as String{
            return HaNamLocation.count
        }
        if self.title == "Hà Tĩnh" as String{
            return HaTinhLocation.count
        }
        if self.title == "Hải Dương" as String{
            return HaiDuongLocation.count
        }
        if self.title == "Hậu Giang" as String{
            return HauGiangLocation.count
        }
        if self.title == "Hoà Bình" as String{
            return HoaBinhLocation.count
        }
        if self.title == "Hưng Yên" as String{
            return HungYenLocation.count
        }
        if self.title == "Khánh Hoà" as String{
            return KhanhHoaLocation.count
        }
        if self.title == "Kiên Giang" as String{
            return KienGiangLocation.count
        }
        if self.title == "Kon Tum" as String{
            return KonTumLocation.count
        }
        if self.title == "Lai Châu" as String{
            return LaiChauLocation.count
        }
        if self.title == "Lâm Đồng" as String{
            return LamDongLocation.count
        }
        if self.title == "Lạng Sơn" as String{
            return LangSonLocation.count
        }
        if self.title == "Lào Cai" as String{
            return LaoCaiLocation.count
        }
        if self.title == "Long An" as String{
            return LongAnLocation.count
        }
        if self.title == "Nam Định" as String{
            return NamDinhLocation.count
        }
        if self.title == "Nghệ An" as String{
            return NgheAnLocation.count
        }
        if self.title == "Ninh Bình" as String{
            return NinhBinhLocation.count
        }
        if self.title == "Ninh Thuận" as String{
            return NinhThuanLocation.count
        }
        if self.title == "Phú Thọ" as String{
            return PhuThoLocation.count
        }
        if self.title == "Phú Yên" as String{
            return PhuYenLocation.count
        }
        if self.title == "Quảng Bình" as String{
            return QuangBinhLocation.count
        }
        if self.title == "Quảng Nam" as String{
            return QuangNamLocation.count
        }
        if self.title == "Quảng Ngãi" as String{
            return QuangNgaiLocation.count
        }
        if self.title == "Quảng Ninh" as String{
            return QuangNinhLocation.count
        }
        if self.title == "Quảng Trị" as String{
            return QuangTriLocation.count
        }
        if self.title == "Sóc Trăng" as String{
            return SocTrangLocation.count
        }
        if self.title == "Sơn La" as String{
            return SonLaLocation.count
        }
        if self.title == "Tây Ninh" as String{
            return TayNinhLocation.count
        }
        if self.title == "Thái Bình" as String{
            return ThaiBinhLocation.count
        }
        if self.title == "Thái Nguyên" as String{
            return ThaiNguyenLocation.count
        }
        if self.title == "Thanh Hoá" as String{
            return ThanhHoaLocation.count
        }
        if self.title == "Thừa Thiên Huế" as String{
            return ThuaThienHueLocation.count
        }
        if self.title == "Tiền Giang" as String{
            return TienGiangLocation.count
        }
        if self.title == "Trà Vinh" as String{
            return TraVinhLocation.count
        }
        if self.title == "Tuyên Quang" as String{
            return TuyenQuangLocation.count
        }
        if self.title == "Vĩnh Long" as String{
            return VinhLongLocation.count
        }
        if self.title == "Vĩnh Phúc" as String{
            return VinhPhucLocation.count
        }
        if self.title == "Yên Bái" as String{
            return YenBaiLocation.count
        }
        return 1
    }
    

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SelectDetailLocationCell") as! SelectDetailLocationCell
        if self.title == "Hà Nội" as String{
            cell.setup(HaNoiLocation[indexPath.item])
        }
        if self.title == "Hồ Chí Minh" as String{
            cell.setup(HoChiMinhLocation[indexPath.item])
        }
        if self.title == "Đông Bắc Bộ" as String{
            cell.setup(DongBacBoLocation[indexPath.item])
        }
        if self.title == "Tây Bắc Bộ" as String{
            cell.setup(TayBacBoLocation[indexPath.item])
        }
        if self.title == "Các tỉnh lân cận Hà Nội" as String{
            cell.setup(CacTinhLanCanHaNoiLocation[indexPath.item])
        }
        if self.title == "Hải Phòng Nam Định Thái Bình" as String{
            cell.setup(HaiPhongNamDinhThaiBinhLocation[indexPath.item])
        }
        if self.title == "Thanh Nghệ Tĩnh" as String{
            cell.setup(ThanhNgheTinhLocation[indexPath.item])
        }
        if self.title == "Bình Trị Thừa Thiên Huế" as String{
            cell.setup(BinhTriThuaThienHueLocation[indexPath.item])
        }
        if self.title == "Quảng Nam Đà Nẵng" as String{
            cell.setup(QuangNamDaNangLocation[indexPath.item])
        }
        if self.title == "Tây Nguyên" as String{
            cell.setup(TayNguyenLocation[indexPath.item])
        }
        if self.title == "Nam Trung Bộ" as String{
            cell.setup(NamTrungBoLocation[indexPath.item])
        }
        if self.title == "Đông Nam Bộ" as String{
            cell.setup(DongNamBoLocation[indexPath.item])
        }
        if self.title == "Cần Thơ - Tây Nam Bộ" as String{
            cell.setup(CanThoTayNamBoLocation[indexPath.item])
        }
        if self.title == "Hải Phòng" as String{
            cell.setup(HaiPhongLocation[indexPath.item])
        }
        if self.title == "Đà Nẵng" as String{
            cell.setup(DaNangLocation[indexPath.item])
        }
        if self.title == "Cần Thơ" as String{
            cell.setup(CanThoLocation[indexPath.item])
        }
        if self.title == "An Giang" as String{
            cell.setup(AnGiangLocation[indexPath.item])
        }
        if self.title == "Bà Rịa Vùng Tàu" as String{
            cell.setup(BaRiaVungTauLocation[indexPath.item])
        }
        if self.title == "Bắc Giang" as String{
            cell.setup(BacGiangLocation[indexPath.item])
        }
        if self.title == "Bắc Cạn" as String{
            cell.setup(BacCanLocation[indexPath.item])
        }
        if self.title == "Bạc Liêu" as String{
            cell.setup(BacLieuLocation[indexPath.item])
        }
        if self.title == "Bắc Ninh" as String{
            cell.setup(BacNinhLocation[indexPath.item])
        }
        if self.title == "Bến Tre" as String{
            cell.setup(BenTreLocation[indexPath.item])
        }
        if self.title == "Bình Định" as String{
            cell.setup(BinhDinhLocation[indexPath.item])
        }
        if self.title == "Bình Dương" as String{
            cell.setup(BinhDuongLocation[indexPath.item])
        }
        if self.title == "Bình Phước" as String{
            cell.setup(BinhPhuocLocation[indexPath.item])
        }
        if self.title == "Bình Thuận" as String{
            cell.setup(BinhThuanLocation[indexPath.item])
        }
        if self.title == "Cà Mau" as String{
            cell.setup(CaMauLocation[indexPath.item])
        }
        if self.title == "Cao Bằng" as String{
            cell.setup(CaoBangLocation[indexPath.item])
        }
        if self.title == "Đắk Lắk" as String{
            cell.setup(DakLakLocation[indexPath.item])
        }
        if self.title == "Đắc Nông" as String{
            cell.setup(DakNongLocation[indexPath.item])
        }
        if self.title == "Điện Biên" as String{
            cell.setup(DienBienLocation[indexPath.item])
        }
        if self.title == "Đồng Nai" as String{
            cell.setup(DongNaiLocation[indexPath.item])
        }
        if self.title == "Đồng Tháp" as String{
            cell.setup(DongThapLocation[indexPath.item])
        }
        if self.title == "Gia Lai" as String{
            cell.setup(GiaLaiLocation[indexPath.item])
        }
        if self.title == "Hà Giang" as String{
            cell.setup(HaGiangLocation[indexPath.item])
        }
        if self.title == "Hà Nam" as String{
            cell.setup(HaNamLocation[indexPath.item])
        }
        if self.title == "Hà Tĩnh" as String{
            cell.setup(HaTinhLocation[indexPath.item])
        }
        if self.title == "Hậu Giang" as String{
            cell.setup(HauGiangLocation[indexPath.item])
        }
        if self.title == "Hoà Bình" as String{
            cell.setup(HoaBinhLocation[indexPath.item])
        }
        if self.title == "Khánh Hoà" as String{
            cell.setup(KhanhHoaLocation[indexPath.item])
        }
        if self.title == "Kiên Giang" as String{
            cell.setup(KienGiangLocation[indexPath.item])
        }
        if self.title == "Kon Tum" as String{
            cell.setup(KonTumLocation[indexPath.item])
        }
        if self.title == "Lai Châu" as String{
            cell.setup(LaiChauLocation[indexPath.item])
        }
        if self.title == "Lâm Đồng" as String{
            cell.setup(LamDongLocation[indexPath.item])
        }
        if self.title == "Lạng Sơn" as String{
            cell.setup(LangSonLocation[indexPath.item])
        }
        if self.title == "Lào Cai" as String{
            cell.setup(LaoCaiLocation[indexPath.item])
        }
        if self.title == "Long An" as String{
            cell.setup(LongAnLocation[indexPath.item])
        }
        if self.title == "Nam Định" as String{
            cell.setup(NamDinhLocation[indexPath.item])
        }
        if self.title == "Nghệ An" as String{
            cell.setup(NgheAnLocation[indexPath.item])
        }
        if self.title == "Ninh Bình" as String{
            cell.setup(NinhBinhLocation[indexPath.item])
        }
        if self.title == "Ninh Thuận" as String{
            cell.setup(NinhThuanLocation[indexPath.item])
        }
        if self.title == "Phú Thọ" as String{
            cell.setup(PhuThoLocation[indexPath.item])
        }
        if self.title == "Phú Yên" as String{
            cell.setup(PhuYenLocation[indexPath.item])
        }
        if self.title == "Quảng Bình" as String{
            cell.setup(QuangBinhLocation[indexPath.item])
        }
        if self.title == "Quảng Ngãi" as String{
            cell.setup(QuangNgaiLocation[indexPath.item])
        }
        if self.title == "Quảng Ninh" as String{
            cell.setup(QuangNinhLocation[indexPath.item])
        }
        if self.title == "Sóc Trăng" as String{
            cell.setup(SocTrangLocation[indexPath.item])
        }
        if self.title == "Sơn La" as String{
            cell.setup(SonLaLocation[indexPath.item])
        }
        if self.title == "Tây Ninh" as String{
            cell.setup(TayNinhLocation[indexPath.item])
        }
        if self.title == "Thái Bình" as String{
            cell.setup(ThaiBinhLocation[indexPath.item])
        }
        if self.title == "Thái Nguyên" as String{
            cell.setup(ThaiNguyenLocation[indexPath.item])
        }
        if self.title == "Thanh Hoá" as String{
            cell.setup(ThanhHoaLocation[indexPath.item])
        }
        if self.title == "Thừa Thiên Huế" as String{
            cell.setup(ThuaThienHueLocation[indexPath.item])
        }
        if self.title == "Tiền Giang" as String{
            cell.setup(TienGiangLocation[indexPath.item])
        }
        if self.title == "Trà Vinh" as String{
            cell.setup(TraVinhLocation[indexPath.item])
        }
        if self.title == "Tuyên Quang" as String{
            cell.setup(TuyenQuangLocation[indexPath.item])
        }
        if self.title == "Vĩnh Long" as String{
            cell.setup(VinhLongLocation[indexPath.item])
        }
        if self.title == "Vĩnh Phúc" as String{
            cell.setup(VinhPhucLocation[indexPath.item])
        }
        if self.title == "Yên Bái" as String{
            cell.setup(YenBaiLocation[indexPath.item])
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch self.title {
        case "Hà Nội":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = HaNoiLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Hồ Chí Minh":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = HoChiMinhLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Đông Bắc Bộ":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = DongBacBoLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Tây Bắc Bộ":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = TayBacBoLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Các tỉnh lân cận Hà Nội":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = CacTinhLanCanHaNoiLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Hải Phòng Nam Định Thái Bình":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = HaiPhongNamDinhThaiBinhLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Thanh Nghệ Tĩnh":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = ThanhNgheTinhLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Bình Trị Thừa Thiên Huế":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = BinhTriThuaThienHueLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Quảng Nam Đà Nẵng":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = QuangNamDaNangLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Tây Nguyên":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = TayNguyenLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Nam Trung Bộ":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = NamTrungBoLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Đông Nam Bộ":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = DongNamBoLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Hải Phòng":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = HaiPhongLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Đà Nẵng":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = DaNangLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Cần Thơ":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = CanThoLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "An Giang":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = AnGiangLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Bà Rịa Vùng Tàu":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = BaRiaVungTauLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Bắc Giang":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = BacGiangLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Bắc Cạn":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = BacCanLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Bạc Liêu":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = BacLieuLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Bắc Ninh":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = BacNinhLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Bến Tre":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = BenTreLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Bình Định":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = BinhDinhLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Bình Dương":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = BinhDuongLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Bình Phước":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = BinhPhuocLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Bình Thuận":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = BinhThuanLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Cà Mau":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = CaMauLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Cao Bằng":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = CaoBangLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Đắk Lắk":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = DakLakLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Đắc Nông":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = DakNongLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Điện Biên":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = DienBienLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Đồng Nai":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = DongNaiLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Gia Lai":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = GiaLaiLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Hà Giang":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = HaGiangLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Hà Nam":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = HaNamLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Hà Tĩnh":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = HaTinhLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Hải Dương":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = HaiDuongLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Hậu Giang":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = HauGiangLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Hoà Bình":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = HoaBinhLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Hưng Yên":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = HungYenLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Khánh Hoà":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = KhanhHoaLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Kiên Giang":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = KienGiangLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Kon Tum":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = KonTumLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Lai Châu":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = LaiChauLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Lâm Đồng":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = LamDongLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Lạng Sơn":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = LangSonLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Lào Cai":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = LaoCaiLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Long An":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = LongAnLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Nam Định":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = NamDinhLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Nghệ An":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = NgheAnLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Ninh Bình":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = NinhBinhLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Ninh Thuận":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = NinhThuanLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Phú Thọ":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = PhuThoLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Phú Yên":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = PhuYenLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Quảng Bình":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = QuangBinhLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Quảng Nam":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = QuangNamLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Quảng Ngãi":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = QuangNgaiLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Quảng Ninh":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = QuangNinhLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Quảng Trị":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = QuangTriLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Sóc Trăng":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = SocTrangLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Sơn La":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = SonLaLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Tây Ninh":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = TayNinhLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Thái Nguyên":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = ThaiNguyenLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Thanh Hoá":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = ThanhHoaLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Thừa Thiên Huế":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = ThuaThienHueLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Tiền Giang":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = TienGiangLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Trà Vinh":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = TraVinhLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Tuyên Quang":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = TuyenQuangLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Vĩnh Long":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = VinhLongLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Vĩnh Phúc":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = VinhPhucLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        case "Yên Bái":
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = YenBaiLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
            
         default:
            if indexPath.item == 0{
                self.delegate?.didSelectDetailLocation(self.title!)
                break
            }
            let location = CanThoTayNamBoLocation[indexPath.item]
            self.delegate?.didSelectDetailLocation(location)
        }

        self.dismiss(animated: true, completion: nil)
    }
}


