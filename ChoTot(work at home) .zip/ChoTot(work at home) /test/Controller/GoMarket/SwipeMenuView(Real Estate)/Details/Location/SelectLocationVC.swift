//
//  SelectLocation.swift
//  test
//
//  Created by Luy Nguyen on 6/3/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

protocol SelectLocationDelegate: NSObjectProtocol {
    func didSelectLocation(_ location: String)
}

class SelectLocationVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var tableView: UITableView!
    
    weak var delegate: SelectLocationDelegate?
    
    var arrayLocation: [String] = ["Toàn quốc", "Hà Nội", "Hồ Chí Minh", "Đông Bắc Bộ", "Tây Bắc Bộ", "Các tỉnh lân cận Hà Nội", "Hải Phòng Nam Định Thái Bình", "Thanh Nghệ Tĩnh", "Bình Trị Thừa Thiên Huế", "Quảng Nam Đà Nẵng", "Tây Nguyên", "Nam Trung Bộ", "Đông Nam Bộ", "Cần Thơ - Tây Nam Bộ"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        
    }
    @IBAction func cancelButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayLocation.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SelectLocationViewCell") as! SelectLocationViewCell
        cell.setup(arrayLocation[indexPath.item])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        if indexPath.item == 0 {
            let location = arrayLocation[indexPath.item]
            self.delegate?.didSelectLocation(location)
            self.dismiss(animated: true, completion: nil)

        } else {
            let locationStoryboard = UIStoryboard(name: "SelectLocation", bundle: nil)
            let selectLocation = locationStoryboard.instantiateViewController(withIdentifier: "Tinh_KhuVuc") as! SelectDetailLocationVC
            selectLocation.title = arrayLocation[indexPath.item]
            selectLocation.delegate = self
            navigationController?.pushViewController(selectLocation, animated: true)
            
        }
    }
}

extension SelectLocationVC: SelectDetailLocationDelegate {
    func didSelectDetailLocation(_ location: String) {
        self.delegate?.didSelectLocation(location)
    }
}


