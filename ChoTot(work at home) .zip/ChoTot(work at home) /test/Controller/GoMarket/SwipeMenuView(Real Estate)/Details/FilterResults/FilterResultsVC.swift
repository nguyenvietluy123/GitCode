//
//  FilterResultsVC.swift
//  test
//
//  Created by Luy Nguyen on 6/10/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import DLRadioButton

protocol FilterResultsDelegate: NSObjectProtocol {
    func getCount(_ count: Int)
}

class FilterResultsVC: UIViewController {
    @IBOutlet weak var btnGroup1: DLRadioButton!
    @IBOutlet weak var btnGroup2_1: DLRadioButton!
    @IBOutlet weak var btnGroup2_2: DLRadioButton!
    @IBOutlet weak var btnGroup3_1: DLRadioButton!
    @IBOutlet weak var btnGroup3_2: DLRadioButton!
    @IBOutlet weak var acceptButton: UIButton!
    
    weak var delegate: FilterResultsDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnGroup2_1.isMultipleSelectionEnabled = true
        btnGroup3_1.isMultipleSelectionEnabled = true
        
    }
    @IBAction func cancelButton(_ sender: Any) {
        self.delegate?.getCount(0)
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func rightBarButtonItem(_ sender: Any) {
        totalCount = 0
        self.delegate?.getCount(totalCount)
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func acceptButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnActionGroup1(_ sender: Any) {

    }
    
    
    var count_1: Int = 0
    var count_2: Int = 0
    var totalCount: Int = 0
    
    @IBAction func btnActionGroup2(_ sender: Any) {
        if btnGroup2_1.isSelected && btnGroup2_2.isSelected {
            count_1 = 1
        }
        if btnGroup2_1.isSelected && btnGroup2_2.isSelected == false {
            count_1 = 1
        }
        if btnGroup2_1.isSelected == false && btnGroup2_2.isSelected {
            count_1 = 1
        }
        if btnGroup2_1.isSelected == false && btnGroup2_2.isSelected == false{
            count_1 = 0
        }
        totalCount = count_1 + count_2
        setAcceptButton(totalCount)
    }
    
    @IBAction func btnActionGroup3(_ sender: Any) {
        if btnGroup3_1.isSelected && btnGroup3_2.isSelected {
            count_2 = 1
        }
        if btnGroup3_1.isSelected && btnGroup3_2.isSelected == false {
            count_2 = 1
        }
        if btnGroup3_1.isSelected == false && btnGroup3_2.isSelected {
            count_2 = 1
        }
        if btnGroup3_1.isSelected == false && btnGroup3_2.isSelected == false{
            count_2 = 0
        }
        totalCount = count_1 + count_2
        setAcceptButton(totalCount)
    }
    
    func setAcceptButton(_ count: Int){
        switch count {
        case 0:
            acceptButton.setTitle("ÁP DỤNG", for: .normal)
        case 1:
            acceptButton.setTitle("ÁP DỤNG(1)", for: .normal)
        default:
            acceptButton.setTitle("ÁP DỤNG(2)", for: .normal)
        }
        self.delegate?.getCount(totalCount)
    }
    
}
