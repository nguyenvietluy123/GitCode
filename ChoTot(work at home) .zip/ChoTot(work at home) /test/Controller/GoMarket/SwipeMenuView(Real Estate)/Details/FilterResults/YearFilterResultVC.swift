//
//  YearFilterResultVC.swift
//  test
//
//  Created by Luy Nguyen on 6/25/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import DLRadioButton

protocol YearFilterResultDelegate: NSObjectProtocol {
    func choseYearFilterResutl(_ year: String)
}

class YearFilterResultVC: UIViewController{
    @IBOutlet weak var tableView: UITableView!

    @IBOutlet weak var labelAll: DLRadioButton!
    @IBOutlet weak var label2017: DLRadioButton!
    @IBOutlet weak var label2018: DLRadioButton!
    @IBOutlet weak var label2019: DLRadioButton!
    @IBOutlet weak var label2020: DLRadioButton!
    @IBOutlet weak var label2021: DLRadioButton!
    @IBOutlet weak var label2022: DLRadioButton!
    @IBOutlet weak var labelAfter2022: DLRadioButton!
    
    weak var yearDelegate: YearFilterResultDelegate?

    @IBAction func acceptButton(_ sender: Any) {
        self.yearDelegate?.choseYearFilterResutl(titleLabel!)
        self.dismiss(animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func cancelButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    var titleLabel: String?
    @IBAction func funcLabelAll(_ sender: Any) {
        if labelAll.isSelected{
            titleLabel = "Năm bàn giao"
        }
        if label2017.isSelected{
            titleLabel = label2017.titleLabel?.text
        }
        if label2018.isSelected{
            titleLabel = label2018.titleLabel?.text
        }
        if label2019.isSelected{
            titleLabel = label2019.titleLabel?.text
        }
        if label2020.isSelected{
            titleLabel = label2020.titleLabel?.text
        }
        if label2021.isSelected{
            titleLabel = label2021.titleLabel?.text
        }
        if label2022.isSelected{
            titleLabel = label2022.titleLabel?.text
        }
        if labelAfter2022.isSelected{
            titleLabel = labelAfter2022.titleLabel?.text
        }
        
    }
    
}
