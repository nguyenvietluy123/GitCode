//
//  ChoosePriceRangeVC.swift
//  test
//
//  Created by Luy Nguyen on 6/10/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import TTRangeSlider

protocol ChooseTotalAreaVCDelegate: NSObjectProtocol {
    func didSelectArea(_ minArea: String, _ maxArea: String)
}

class ChooseTotalAreaVC: UIViewController, TTRangeSliderDelegate {
    @IBOutlet weak var containView: UIView!
    @IBOutlet weak var labelMinArea: UILabel!
    @IBOutlet weak var labelMaxArea: UILabel!
    
    weak var delegate: ChooseTotalAreaVCDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupRangeSlider()
    }
    
    @IBAction func cancelButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func acceptButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    func setupRangeSlider() {
        let labelWidth: CGFloat = containView.bounds.width - 32
        let labelHeigh: CGFloat = 40
        let labelX = CGFloat(containView.bounds.width / 2) - (labelWidth / 2)
        let labelY = CGFloat(containView.bounds.height - 50)
        let sliderView = TTRangeSlider(frame:  CGRect(x: labelX, y: labelY, width: labelWidth, height: labelHeigh))
        sliderView.delegate = self
        sliderView.maxValue = 1000
        sliderView.minValue = 0
        sliderView.selectedMinimum = 0
        sliderView.selectedMaximum = 1000
        sliderView.lineHeight = 6
        
        sliderView.enableStep = true
        sliderView.step = 5
        
        sliderView.handleColor = UIColor.white
        sliderView.handleBorderColor = UIColor.gray
        sliderView.handleBorderWidth = 0.5
        sliderView.handleDiameter = 30
        
        sliderView.hideLabels = false
        sliderView.minLabelColour = UIColor.black
        sliderView.maxLabelColour = UIColor.black
        
        sliderView.tintColorBetweenHandles = UIColor.orange
        
        sliderView.lineBorderColor = UIColor.lightGray
        sliderView.lineBorderWidth = 10
        
        containView.addSubview(sliderView)
    }
    func rangeSlider(_ sender: TTRangeSlider!, didChangeSelectedMinimumValue selectedMinimum: Float, andMaximumValue selectedMaximum: Float) {
        let getMinPrice = Int(selectedMinimum)
        let myIntStringMin = getMinPrice.formattedWithSeparator
        labelMinArea.text = myIntStringMin
        
        let getMaxPrice = Int(selectedMaximum)
        let myIntStringMax = getMaxPrice.formattedWithSeparator
        labelMaxArea.text = myIntStringMax
        
        self.delegate?.didSelectArea(labelMinArea.text!, labelMaxArea.text!)
    }
    
}
