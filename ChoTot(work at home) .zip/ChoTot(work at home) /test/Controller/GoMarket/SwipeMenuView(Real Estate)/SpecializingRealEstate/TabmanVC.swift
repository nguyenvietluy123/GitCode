//
//  TabmanVC.swift
//  test
//
//  Created by Luy Nguyen on 7/5/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import Tabman
import Pageboy

protocol TabmanDelegate: NSObjectProtocol {
    func getConstrain(_ constrain: CGFloat)
    
}

class TabmanVC: TabmanViewController {
    var delegateFromNearlyActivityVC: TabmanDelegate?
    var viewControllers = [UIViewController]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.dataSource = self
        self.bar.items = [Item(title: "Hoạt Động Gần Nhất"), Item(title: "Nhiều Dự Án Nhất"), Item(title: "Nhiều Tin Đăng Nhất")]
        
        self.bar.appearance = TabmanBar.Appearance({ (appearance) in
            appearance.indicator.color = UIColor.orange
            appearance.text.font = .systemFont(ofSize: 16.0)
        })
        
        changeMode()
    }

    func changeMode() {
        let productStoryboard = UIStoryboard.init(name: "Products", bundle: nil)
        if mode == "3lines"{
            let vc1 = productStoryboard.instantiateViewController(withIdentifier: "NearlyActivityLinesVC") as? NearlyActivityVC
            let vc2 = productStoryboard.instantiateViewController(withIdentifier: ProjectVC.className)
            vc1?.delegateConstrain = self
            viewControllers.append(vc1!)
            viewControllers.append(vc2)
            self.reloadPages()
        }else{
            let vc1 = productStoryboard.instantiateViewController(withIdentifier: "NearlyActivitySquaresVC") as? NearlyActivityVC
            vc1?.delegateConstrain = self
            viewControllers.append(vc1!)
            self.reloadPages()
        }
    }
}

extension TabmanVC: PageboyViewControllerDataSource {
    func numberOfViewControllers(in pageboyViewController: PageboyViewController) -> Int {
        return viewControllers.count
    }
    
    func viewController(for pageboyViewController: PageboyViewController, at index: PageboyViewController.PageIndex) -> UIViewController? {
        return viewControllers[index]
    }
    
    func defaultPage(for pageboyViewController: PageboyViewController) -> PageboyViewController.Page? {
        return nil
    }
}

extension TabmanVC : NearlyActivityDelegate {
    func getContensizeOfCollectionView(_ constrain: CGFloat) {
        self.delegateFromNearlyActivityVC?.getConstrain(constrain)
    }
    
    
}

