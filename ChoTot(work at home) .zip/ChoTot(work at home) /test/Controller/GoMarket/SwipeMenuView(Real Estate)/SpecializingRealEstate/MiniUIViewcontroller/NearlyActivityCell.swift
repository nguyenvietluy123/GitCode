//
//  NearlyActivityCell.swift
//  test
//
//  Created by Luy Nguyen on 6/28/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class NearlyActivityCell: UICollectionViewCell {
    @IBOutlet weak var branch: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var location: UIImageView!
    
    func setup(_ item: PageRealEstate){
        self.branch.image = item.branch
        self.title.text = item.title
        self.address.text = item.address
        self.location.image = item.location
        
    }
    
}
