//
//  NearlyActivityVC.swift
//  test
//
//  Created by Luy Nguyen on 6/28/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

struct PageRealEstate {
    var branch: UIImage
    var title: String
    var address: String
    var location: UIImage
}

protocol NearlyActivityDelegate: NSObjectProtocol {
    func getContensizeOfCollectionView(_ constrain: CGFloat)
}

class NearlyActivityVC: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!

    var arrayData = [PageRealEstate]()
    

    weak var delegateConstrain: NearlyActivityDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.dataSource = self
        collectionView.delegate = self
        
        collectionView.alwaysBounceVertical = true
        
        let item = PageRealEstate(branch: #imageLiteral(resourceName: "p5"), title: "Chuyên trang BĐS Mr. Hoàng", address: "Xóm giang hồ Bách Khoa", location: #imageLiteral(resourceName: "0677f4d6a59469c336a19ebcf2794"))
        let item1 = PageRealEstate(branch: #imageLiteral(resourceName: "p"), title: "Chuyên trang BĐS Mầm Non", address: "Mầm Non Ánh Hồng", location: #imageLiteral(resourceName: "0677f4d6a59469c336a19ebcf2794"))
        let item2 = PageRealEstate(branch: #imageLiteral(resourceName: "p6"), title: "Chuyên trang BĐS Bớt Đây", address: "Wedding Store", location: #imageLiteral(resourceName: "0677f4d6a59469c336a19ebcf2794"))
        let item3 = PageRealEstate(branch: #imageLiteral(resourceName: "p3"), title: "Chuyên trang BĐS Tôm Hùm", address: "Ocean", location: #imageLiteral(resourceName: "0677f4d6a59469c336a19ebcf2794"))
        let item4 = PageRealEstate(branch: #imageLiteral(resourceName: "p1"), title: "Chuyên trang BĐS Đa Cấp", address: "Phạm Văn Đồng", location: #imageLiteral(resourceName: "0677f4d6a59469c336a19ebcf2794"))
        let item5 = PageRealEstate(branch: #imageLiteral(resourceName: "p4"), title: "Chuyên trang BĐS Menly", address: "Nguyễn Viết Luỹ", location: #imageLiteral(resourceName: "0677f4d6a59469c336a19ebcf2794"))
        let item6 = PageRealEstate(branch: #imageLiteral(resourceName: "p2"), title: "Chuyên trang BĐS Thành Long Partner", address: "China", location: #imageLiteral(resourceName: "0677f4d6a59469c336a19ebcf2794"))
        let item7 = PageRealEstate(branch: #imageLiteral(resourceName: "photo_dog"), title: "Chuyên trang BĐS Con Cún", address: "Cage", location: #imageLiteral(resourceName: "0677f4d6a59469c336a19ebcf2794"))
        arrayData.append(item)
        arrayData.append(item1)
        arrayData.append(item2)
        arrayData.append(item3)
        arrayData.append(item4)
        arrayData.append(item5)
        arrayData.append(item6)
        arrayData.append(item7)
        
        
        collectionView.reloadData()
    }
    
    var offSet: CGFloat = 0
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        delegateConstrain?.getContensizeOfCollectionView(collectionView.contentOffset.y)
    }

}

extension NearlyActivityVC: UICollectionViewDelegate, UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrayData.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NearlyActivityCell", for: indexPath) as! NearlyActivityCell
        cell.setup(arrayData[indexPath.item])
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("select")
    }
}

extension NearlyActivityVC: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            let collectionSize = collectionView.frame.size
            var size = CGSize()
        if mode == "4squares" {
            size.width = collectionSize.width / 2 - 5
            size.height = 200
            return size
        }else {
            size.width = collectionSize.width - 4
            size.height = 70
            return size
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 8
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
}


