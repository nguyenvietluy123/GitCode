//
//  SpecializingRealEstateVC.swift
//  test
//
//  Created by Luy Nguyen on 6/28/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import Tabman
import SwipeMenuViewController


var mode: String = "3lines"
class SpecializingRealEstateVC: UIViewController {
    @IBOutlet weak var modeLine: UIButton!
    @IBOutlet weak var modeSquare: UIButton!
    @IBOutlet weak var locationLabel: UIButton!
    @IBOutlet weak var topView: NSLayoutConstraint!
    @IBOutlet weak var tabmanView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        modeSquare.imageView?.alpha = 0.3
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "tabmanSegue" {
            let vc = segue.destination as! TabmanVC
            vc.delegateFromNearlyActivityVC = self
        }
    }
    @IBAction func selectLocationButton(_ sender: Any) {
        let selectStoryboard = UIStoryboard(name: "SelectLocation", bundle: nil)
        let selectCityProvinceVC = selectStoryboard.instantiateViewController(withIdentifier: CityProvinceVC.className) as! CityProvinceVC
        selectCityProvinceVC.delegate = self
        let nav = UINavigationController(rootViewController: selectCityProvinceVC)
        self.present(nav, animated: true, completion: nil)
    }
    
    
    @IBAction func modeLineButton(_ sender: Any) {
        if modeLine.imageView?.image == UIImage(named: "icon_3lines_selected"){
            return
        }
        modeLine.setImage(#imageLiteral(resourceName: "icon_3lines_selected"), for: .normal)
        modeSquare.setImage(#imageLiteral(resourceName: "icon_4squares_default"), for: .normal)
        modeSquare.imageView?.alpha = 0.3
        mode = "3lines"
        
        let productStoryboard = UIStoryboard(name: "Products", bundle: nil)
        let vc = productStoryboard.instantiateViewController(withIdentifier: "TabmanVC") as! TabmanVC
        tabmanView.addSubview(vc.view)
        addChildViewController(vc)
        vc.didMove(toParentViewController: self)
        vc.delegateFromNearlyActivityVC = self        
        vc.reloadPages()
    }
    @IBAction func modeSquareButton(_ sender: Any) {
        if modeSquare.imageView?.image == UIImage(named: "icon_4squares_selected"){
            return
        }
        modeSquare.setImage(#imageLiteral(resourceName: "icon_4squares_selected"), for: .normal)
        modeLine.setImage(#imageLiteral(resourceName: "icon_3lines_default"), for: .normal)
        modeLine.imageView?.alpha = 0.3
        mode = "4squares"
        
        let productStoryboard = UIStoryboard(name: "Products", bundle: nil)
        let vc = productStoryboard.instantiateViewController(withIdentifier: "TabmanVC") as! TabmanVC
        tabmanView.addSubview(vc.view)
        addChildViewController(vc)
        vc.didMove(toParentViewController: self)
        vc.delegateFromNearlyActivityVC = self
        vc.reloadPages()
    }
}

extension SpecializingRealEstateVC: SelectLocationDelegate, TabmanDelegate{
    func getConstrain(_ constrain: CGFloat) {
        var offSet: CGFloat = 0
        if offSet < constrain {
            UIView.animate(withDuration: 0.2, animations: {
                self.topView.constant = -100
                self.view.layoutIfNeeded()
            })
            offSet = constrain
        }
        if offSet > constrain {
            UIView.animate(withDuration: 0.2, animations: {
                self.topView.constant = 0
                self.view.layoutIfNeeded()
            })
            offSet = constrain
        }
    }
    
    func didSelectLocation(_ location: String) {
        locationLabel.setTitle(location, for: .normal)
    }
}

