//
//  horizontalCell.swift
//  test
//
//  Created by Luy Nguyen on 6/25/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class horizontalCell: UICollectionViewCell {
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var labelPrice: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    
    func setup(_ item: FireBaseProduct){
        self.labelTitle.text = String(item.title)
        //        self.labelPrice.text = String(item.price)
        
        let getPrice = Int(item.price)
        let myIntString = getPrice.formattedWithSeparator
        self.labelPrice.text = myIntString
        
        let url: URL = URL(string: item.image)!
//        do {
//            let data: Data = try Data(contentsOf: url)
//            imageView.image = UIImage(data: data)
//        }
//        catch{
//            print("loading error")
//        }
        
        imageView.sd_setImage(with: url, completed: nil)
        //        let baseUrl = "http://api.baongocstore.com/storage/"
        //        imageView.sd_setImage(with: URL(string: baseUrl + item.featured_image), placeholderImage: UIImage(named: "\(#imageLiteral(resourceName: "icon_eye"))"))
        
        labelTitle.numberOfLines = 0
        labelTitle.textColor = UIColor.black
    }
}
