//
//  RealEstate+.swift
//  test
//
//  Created by Luy Nguyen on 6/8/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//
import UIKit

extension PurchaseVC: UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayVerticalCell.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "verticalCell", for: indexPath) as! verticalCell
        cell.setup(arrayVerticalCell[indexPath.item])
        return cell
    }
}
