//
//  PurchaseVC.swift
//  test
//
//  Created by Luy Nguyen on 6/19/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class PurchaseVC: UIViewController {
    @IBOutlet weak var customXibWithButtonView: MuaBanVaChoThue!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var horizontalCollectionView: UICollectionView!
    
    var arrayHorizontalCell = [FireBaseProduct]()
    var arrayVerticalCell = [FireBaseProduct]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        horizontalCollectionView.delegate = self
        horizontalCollectionView.dataSource = self
        tableView.delegate = self
        tableView.dataSource = self
        
//        Api.shared.fetchProducts { (productInfo, error) in
//            guard error == nil else{
//                print("system error")
//                return
//            }
//            self.arrayHorizontalCell = productInfo.data
//            self.arrayVerticalCell = productInfo.data
//            self.horizontalCollectionView.reloadData()
//            self.tableView.reloadData()
//        }
        
        var ref: DatabaseReference!
        ref = Database.database().reference()
        ref.child("data").observe(DataEventType.value) { (snapshot) in
            for data in snapshot.children{
                let product = FireBaseProduct(data as! DataSnapshot)
                self.arrayHorizontalCell.append(product)
                self.horizontalCollectionView.reloadData()
            }
        }

        ref.child("SellHouse").observe(DataEventType.value) { (snapshot) in
            for data in snapshot.children {
                let product = FireBaseProduct(data as! DataSnapshot)
                self.arrayVerticalCell.append(product)
                self.tableView.reloadData()
            }
        }
        
        setXibView()
    }
    
    func setXibView() {
        customXibWithButtonView.touchUpLocation = { (text) in
            let selectStoryboard = UIStoryboard(name: "SelectLocation", bundle: nil)
            let selectLocationVC = selectStoryboard.instantiateViewController(withIdentifier: SelectLocationVC.className) as! SelectLocationVC
            selectLocationVC.delegate = self
            let nav = UINavigationController(rootViewController: selectLocationVC)
            self.navigationController?.present(nav, animated: true, completion: nil)
        }
        customXibWithButtonView.touchUpLandscaping = { (text) in
            let selectStoryboard = UIStoryboard(name: "SelectLocation", bundle: nil)
            let landscapingVC = selectStoryboard.instantiateViewController(withIdentifier: LandscapingVC.className) as! LandscapingVC
            landscapingVC.delegate = self
            let nav = UINavigationController(rootViewController: landscapingVC)
            self.navigationController?.present(nav, animated: true, completion: nil)
        }
        customXibWithButtonView.touchUpPriceRange = {(text) in
            let selectPriceRangeStoryBoard = UIStoryboard(name: "ChoosePriceRangeAndTotalArea", bundle: nil)
            let choosePriceRangeVC = selectPriceRangeStoryBoard.instantiateViewController (withIdentifier:  ChoosePriceRangeVC.className) as! ChoosePriceRangeVC
            choosePriceRangeVC.delegate = self
            let nav = UINavigationController(rootViewController: choosePriceRangeVC)
            self.navigationController?.present(nav, animated: true, completion: nil)
        }
        customXibWithButtonView.touchUpTotalArea = {(text) in
            let selectTotalAreaStoryboard = UIStoryboard(name: "ChoosePriceRangeAndTotalArea", bundle: nil)
            let chooseTotalAreaVC = selectTotalAreaStoryboard.instantiateViewController(withIdentifier: ChooseTotalAreaVC.className) as! ChooseTotalAreaVC
            chooseTotalAreaVC.delegate = self
            let nav = UINavigationController(rootViewController: chooseTotalAreaVC)
            self.navigationController?.present(nav, animated: true, completion: nil)
        }
        customXibWithButtonView.touchUpFilterResults = {(text) in
            let choosePriceRangeStoryBoard = UIStoryboard(name: "FilterResults", bundle: nil)
            let filterResultsVC = choosePriceRangeStoryBoard.instantiateViewController(withIdentifier: FilterResultsVC.className) as! FilterResultsVC
            filterResultsVC.delegate = self
            let nav = UINavigationController(rootViewController: filterResultsVC)
            self.navigationController?.present(nav, animated: true, completion: nil)
        }
    }

}

extension PurchaseVC: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrayHorizontalCell.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "horizontalCell", for: indexPath) as! horizontalCell
        cell.setup(arrayHorizontalCell[indexPath.item])
        return cell
    }
}

extension PurchaseVC: SelectLocationDelegate, LandscapingDelegate, ChoosePriceRangeDelegate, ChooseTotalAreaVCDelegate, FilterResultsDelegate{
    func didSelectLocation(_ location: String) {
        customXibWithButtonView.selectLocation.setTitle(location, for: .normal)
    }
    func didSelectLandscaping(_ landscaping: String) {
        customXibWithButtonView.kindsOfLandscaping.setTitle(landscaping, for: .normal)
    }
    func didChoosePriceRange(_ minPriceRange: String, maxPriceRange: String) {
        customXibWithButtonView.priceRange.setTitle("\(minPriceRange) đ - \(maxPriceRange) +đ", for: .normal)
    }
    func didSelectArea(_ minArea: String, _ maxArea: String) {
        customXibWithButtonView.areaRange.setTitle(("\(minArea) m² - \(maxArea) +m²"), for: .normal)
    }
    func getCount(_ count: Int) {
        switch count {
        case 0:
            customXibWithButtonView.miniCount.isHidden = true
        case 1:
            customXibWithButtonView.miniCount.isHidden = false
            customXibWithButtonView.miniCount.setTitle("1", for: .normal)
        default:
            customXibWithButtonView.miniCount.isHidden = false
            customXibWithButtonView.miniCount.setTitle("2", for: .normal)
        }
    }
    
}








