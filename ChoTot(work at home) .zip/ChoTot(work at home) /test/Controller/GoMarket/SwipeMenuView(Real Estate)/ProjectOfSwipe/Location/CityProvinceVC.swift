//
//  CityProvinceVC.swift
//  test
//
//  Created by Luy Nguyen on 6/20/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit


class CityProvinceVC: UIViewController {
    @IBOutlet weak var nationwideButton: UIButton!
    
    weak var delegate: SelectLocationDelegate?
    
    let cityArray : [String] = ["Hà Nội", "Hồ Chí Minh", "Hải Phòng", "Đà Nẵng", "Cần Thơ"]
    let provinceArray : [String] = ["An Giang", "Bà Rịa Vùng Tàu", "Bắc Giang", "Bắc Cạn", "Bạc Liêu", "Bắc Ninh", "Bến Tre", "Bình Định", "Bình Dương", "Bình Phước", "Bình Thuận", "Cà Mau", "Cao Bằng", "Đắk Lắk", "Đắc Nông", "Điện Biên", "Đồng Nai", "Đồng Tháp", "Gia Lai", "Hà Giang", "Hà Nam", "Hà Tĩnh", "Hải Dương", "Hậu Giang", "Hoà Bình", "Hưng Yên", "Khánh Hoà", "Kiên Giang", "Kon Tum", "Lai Châu", "Lâm Đồng", "Lạng Sơn", "Lào Cai", "Long An", "Nam Định", "Nghệ An", "Ninh Bình", "Ninh Thuận", "Phú Thọ", "Phú Yên", "Quảng Bình", "Quảng Nam", "Quảng Ngãi", "Quảng Ninh", "Quảng Trị", "Sóc Trăng", "Sơn La", "Tây Ninh", "Thái Bình", "Thái Nguyên", "Thanh Hoá", "Thừa Thiên Huế", "Tiền Giang", "Trà Vinh", "Tuyên Quang", "Vĩnh Long", "Vĩnh Phúc", "Yên Bái"]
    
    @IBOutlet weak var TableViewCity: UITableView!
    @IBOutlet weak var TableViewProvince: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        TableViewCity.delegate = self
        TableViewProvince.delegate = self
        TableViewCity.dataSource = self
        TableViewProvince.dataSource = self
        
    
    }
    
    @IBAction func cancelButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }

}

extension CityProvinceVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch tableView {
        case TableViewCity:
            return cityArray.count
        default:
            return provinceArray.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item = tableView.dequeueReusableCell(withIdentifier: "CityProvinceCell") as? CityProvinceCell
        switch tableView {
        case TableViewCity:
            item?.setup(cityArray[indexPath.item])
        default:
            item?.setup(provinceArray[indexPath.item])
        }
        return item!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let locationStoryboard = UIStoryboard(name: "SelectLocation", bundle: nil)
        let selectLocation = locationStoryboard.instantiateViewController(withIdentifier: "Tinh_KhuVuc") as! SelectDetailLocationVC
        selectLocation.delegate = self
        switch tableView {
        case TableViewCity:
            selectLocation.title = cityArray[indexPath.item]
        default:
            selectLocation.title = provinceArray[indexPath.item]
        }
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        
        navigationController?.pushViewController(selectLocation, animated: true)
    }
    
}

extension CityProvinceVC: SelectDetailLocationDelegate {
    func didSelectDetailLocation(_ location: String) {
        self.delegate?.didSelectLocation(location)
    }
}
