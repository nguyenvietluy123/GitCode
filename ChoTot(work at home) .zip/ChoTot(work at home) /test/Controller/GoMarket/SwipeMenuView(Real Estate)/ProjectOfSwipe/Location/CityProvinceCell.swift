//
//  CityProvinceCell.swift
//  test
//
//  Created by Luy Nguyen on 6/21/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class CityProvinceCell: UITableViewCell {
    @IBOutlet weak var nameLabel: UILabel!
    
    func setup(_ name: String){
        nameLabel.text = name
    }
}

