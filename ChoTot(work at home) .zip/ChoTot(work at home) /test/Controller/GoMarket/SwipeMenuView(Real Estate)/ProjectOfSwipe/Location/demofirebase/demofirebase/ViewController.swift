//
//  ViewController.swift
//  demofirebase
//
//  Created by Luy Nguyen on 6/20/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
class ViewController: UIViewController {
    var ref: DatabaseReference!

    @IBOutlet weak var txt: UILabel!
    override func viewDidLoad() {
        
        ref = Database.database().reference()

        self.ref.child("khoahoc1").setValue("ios")
        self.ref.child("khoahoc1").observe(DataEventType.value) { (data) in
            print(data.value)
            
            self.txt.text = data.value as? String
        }
        super.viewDidLoad()
    }

   


}

