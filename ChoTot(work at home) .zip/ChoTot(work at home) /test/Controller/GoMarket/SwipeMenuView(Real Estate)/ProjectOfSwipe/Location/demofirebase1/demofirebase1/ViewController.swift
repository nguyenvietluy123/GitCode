//
//  ViewController.swift
//  demofirebase1
//
//  Created by Luy Nguyen on 6/20/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class ViewController: UIViewController {
    var ref: DatabaseReference!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ref = Database.database().reference()
        
        // Do any additional setup after loading the view, typically from a nib.
        
        self.ref.child("khoahoc").observe(DataEventType.value) { (data) in
            print(data.value)
        }
        
        self.ref.child("khoahoc").setValue("Lap trinh ios 02")
    }

    

}

