
//
//  ProjectCell.swift
//  test
//
//  Created by Luy Nguyen on 6/29/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class ProjectCell: UITableViewCell {

    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var year: UILabel!
    
    func setup(_ item: FireBaseProduct){
        self.title.text = item.title
        self.address.text = item.address
        self.year.text = item.status
        
        let getPrice = Int(item.price)
        let myIntString = getPrice.formattedWithSeparator
        self.price.text = myIntString
        
        let url: URL = URL(string: item.image)!
        img.sd_setImage(with: url, completed: nil)
//        do {
//            let data: Data = try Data(contentsOf: url)
//            self.img.image = UIImage(data: data)
//        }
//        catch{
//            print("loading error")
//        }
    }
}
