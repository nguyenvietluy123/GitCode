//
//  ProjectVC.swift
//  test
//
//  Created by Luy Nguyen on 6/20/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class ProjectVC: UIViewController {
    @IBOutlet weak var locationLabel: CustomButton!
    @IBOutlet weak var priceRangeLabel: CustomButton!
    @IBOutlet weak var yearFilterResultLabel: CustomButton!
    @IBOutlet weak var tableView: UITableView!
    
    var projectArray = [FireBaseProduct]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.estimatedRowHeight = 150
        
        var ref: DatabaseReference!
        ref = Database.database().reference()

        ref.child("Project").observe(DataEventType.value) { (snapshot) in
            for data in snapshot.children {
                let product = FireBaseProduct(data as! DataSnapshot)
                self.projectArray.append(product)
                self.tableView.reloadData()
            }
        }
        
    }

    @IBAction func selectLocation(_ sender: Any) {
        let selectStoryboard = UIStoryboard(name: "SelectLocation", bundle: nil)
        let selectCityProvinceVC = selectStoryboard.instantiateViewController(withIdentifier: CityProvinceVC.className) as! CityProvinceVC
        selectCityProvinceVC.delegate = self
        let nav = UINavigationController(rootViewController: selectCityProvinceVC)
        self.present(nav, animated: true, completion: nil)
    }
    
    @IBAction func selectPriceRange(_ sender: Any) {
        let selectStoryboard = UIStoryboard(name: "ChoosePriceRangeAndTotalArea", bundle: nil)
        let choosePriceRange2VC = selectStoryboard.instantiateViewController(withIdentifier: "ChoosePriceRange2VC") as? ChoosePriceRange2VC
        choosePriceRange2VC?.delegate = self
        let nav = UINavigationController(rootViewController: choosePriceRange2VC!)
        self.present(nav, animated: true, completion: nil)
    }
    
    @IBAction func yearHandover(_ sender: Any) {
        let selectStoryboard = UIStoryboard(name: "FilterResults", bundle: nil)
        let yearFilterResultVC = selectStoryboard.instantiateViewController(withIdentifier: "YearFilterResultVC") as? YearFilterResultVC
        yearFilterResultVC?.yearDelegate = self
        let nav = UINavigationController(rootViewController: yearFilterResultVC!)
        self.present(nav, animated: true, completion: nil)
    }
}

extension ProjectVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 225
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return projectArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProjectCell") as! ProjectCell
        cell.setup(projectArray[indexPath.item])
        return cell
    }
}

extension ProjectVC: SelectLocationDelegate, ChoosePriceRangeDelegate, YearFilterResultDelegate {
    func didSelectLocation(_ location: String) {
        locationLabel.setTitle(location, for: .normal)
    }
    
    func didChoosePriceRange(_ minPriceRange: String, maxPriceRange: String) {
        priceRangeLabel.setTitle("\(minPriceRange) đ - \(maxPriceRange) +đ", for: .normal)
    }
    
    func choseYearFilterResutl(_ year: String) {
        yearFilterResultLabel.setTitle(year, for: .normal)
    }
    
    
    
}
