//
//  SwipeMenuViewVC.swift
//  test
//
//  Created by Luy Nguyen on 7/4/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import SwipeMenuViewController


class SwipeMenuViewVC: SwipeMenuViewController, UISearchBarDelegate {

    @IBOutlet weak var viewForSwipe: UIView!
    @IBOutlet weak var myLabel: UILabel!
    @IBOutlet weak var viewForMyLabel: UIView!
    
    var arraySwipe: [String] = ["MUA BÁN   ", "CHO THUÊ   ", "DỰ ÁN   ", "CHUYÊN TRANG BĐS   "]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        swipeMenuView.dataSource = self
        swipeMenuView.delegate = self
        
        var option : SwipeMenuViewOptions = .init()
        option.tabView.underlineView.backgroundColor = UIColor.orange
        swipeMenuView.reloadData(options: option)
        
        myLabel.sizeToFit()
        myLabel.isHidden = true
        myLabel.adjustsFontSizeToFitWidth = true
        viewForMyLabel.isHidden = true
        
        setNavigationOnTOp()
    }
    
    func setNavigationOnTOp(){
        let searchBar = UISearchBar()
        searchBar.placeholder = "Tìm kiếm Bất động sản"
        searchBar.barStyle = .black
        searchBar.delegate = self
        navigationItem.titleView = searchBar
       
        let rightBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "icon_bookmark_normal"), style: .plain, target: self, action: #selector(changeRightBarButtonItem))
        rightBarButtonItem.tintColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        navigationItem.rightBarButtonItem = rightBarButtonItem
    }
    
    @objc func changeRightBarButtonItem() {
        myLabel.isHidden = false
        viewForMyLabel.isHidden = false
        if navigationItem.rightBarButtonItem?.image == UIImage(named: "icon_bookmark_normal"){
            navigationItem.rightBarButtonItem?.image = UIImage(named: "icon_bookmark_selected")
            myLabel.text = "Bạn sẽ nhận được thông báo mới cho tin rao mới thông qua tìm kiếm đã lưu"
            myLabel.textAlignment = .left
            navigationItem.rightBarButtonItem?.tintColor = #colorLiteral(red: 0.7450980544, green: 0.1568627506, blue: 0.07450980693, alpha: 1)
        }else{
            navigationItem.rightBarButtonItem?.image = UIImage(named: "icon_bookmark_normal")
            myLabel.text = "Bạn đã huỷ theo dõi tìm kiếm này"
            navigationItem.rightBarButtonItem?.tintColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        }
        /*---->*/ Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { (hidden) in
            self.myLabel.isHidden = true
            self.viewForMyLabel.isHidden = true
        }
    }
    
    override func numberOfPages(in swipeMenuView: SwipeMenuView) -> Int {
        return arraySwipe.count
    }
    
    override func swipeMenuView(_ swipeMenuView: SwipeMenuView, titleForPageAt index: Int) -> String {
        return arraySwipe[index]
    }
    
    override func swipeMenuView(_ swipeMenuView: SwipeMenuView, viewControllerForPageAt index: Int) -> UIViewController {
        switch index {
        case 0:
            return pushProductVC("PurchaseVC")
        case 1:
            return pushProductVC("ForRentVC")
        case 2:
            return pushProductVC("ProjectVC")
        default:
            return pushProductVC("SpecializingRealEstateVC")
        }
    }
    
    func pushProductVC(_ category: String) -> UIViewController{
        let productsStoryBoard = UIStoryboard(name: "Products", bundle: nil)
        let nameVC = productsStoryBoard.instantiateViewController(withIdentifier: "\(category)")
        addChildViewController(nameVC)
        return nameVC
    }
}

