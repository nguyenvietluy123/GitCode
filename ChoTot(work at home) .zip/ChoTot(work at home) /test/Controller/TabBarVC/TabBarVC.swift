//
//  TabBarVC.swift
//  test
//
//  Created by Luy Nguyen on 5/13/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class TabBarVC: UITabBarController, UITabBarControllerDelegate {

    @IBOutlet weak var tabbar: UITabBar!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
        if let email = UserDefaults.standard.string(forKey: EMAIL_KEY){
            if let password = UserDefaults.standard.string(forKey: PASSWORD_KEY){
                Api.shared.login(email: email, password: password) { (error, isSucess) in
                }
            }
        }
    }
    
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        switch viewController.className{
        case /*NotificationVC.className*/ SellingTableVC.className:
            if Api.shared.token == ""{
                showLoginVC()
                return false
            }else{
                return true
            }
        default:
            return true
        }
    }

    func showLoginVC() {
        let mainStoryBoard = UIStoryboard.init(name: "Main", bundle: nil)
        let loginVC = mainStoryBoard.instantiateViewController(withIdentifier: LoGinVC.className)
        self.present(loginVC, animated: true) {
            print("present login vc finish")
        }
    }

}
