//
//  SellingCell.swift
//  test
//
//  Created by Luy Nguyen on 5/19/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import SDWebImage

class SellingCell: UITableViewCell {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var imgHinh : UIImageView!
    @IBOutlet weak var price : UILabel!
    @IBOutlet weak var dateCreated : UILabel!
    func setupCell(_ item: Product) {
        nameLabel.text = item.name
        
        //setprice
        let getPrice = Int(item.retail_price)
        let myIntString = getPrice?.formattedWithSeparator
        price.text = myIntString
        

        //set image
        let baseUrl = "http://api.baongocstore.com/storage/"
        imgHinh.sd_setImage(with: URL(string: baseUrl + item.featured_image), placeholderImage: UIImage(named: "\(#imageLiteral(resourceName: "icon_eye"))"))
        
        
        //setdate
        dateCreated.text = String(describing: item.created_at)
        
    }

}
