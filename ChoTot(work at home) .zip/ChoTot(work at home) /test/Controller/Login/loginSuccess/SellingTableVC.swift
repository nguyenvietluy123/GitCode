//
//  SellingTableVC.swift
//  test
//
//  Created by Luy Nguyen on 5/19/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class SellingTableVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var arrayData = [Product]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        
        Api.shared.fetchProducts { (productInfo, error) in
            guard error == nil else{
                print(error ?? "system error")
                return
            }
            self.arrayData = productInfo.data
            self.tableView.reloadData()
        }
    }


}

extension SellingTableVC: UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return 100
    }

}

extension SellingTableVC: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SellingCell") as! SellingCell
        let item = arrayData[indexPath.item]
        cell.setupCell(item)
        return cell
    }
}
