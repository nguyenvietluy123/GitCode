//
//  LoGinVC.swift
//  test
//
//  Created by Luy Nguyen on 5/12/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import Alamofire
var isLoginSuccess: Bool = false
let EMAIL_KEY = "EMAIL_KEY"
let PASSWORD_KEY = "PASSWORD_KEY"
class LoGinVC: UIViewController, UITabBarControllerDelegate {
    
    @IBOutlet weak var viewTextField: UITableView!
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    var isLoginSucces: Bool = false
    
    @IBAction func secureTextButton(_ sender: Any) {
        if passwordTextField.isSecureTextEntry == false {
            passwordTextField.isSecureTextEntry = true
        }else{
            passwordTextField.isSecureTextEntry = false
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewTextField.layer.cornerRadius = 5
        
        userNameTextField.text = "admin@example.com"
        passwordTextField.text = "12345678"
    }
    
    @IBAction func missPasswordAction(_ sender: UIButton){
        //                let mainStoryBoard = UIStoryboard.init(name: "Main", bundle: nil)
        //
        //                let marketVC = mainStoryBoard.instantiateViewController(withIdentifier: "quenmatkhau")
        //
        //                self.navigationController?.pushViewController(marketVC, animated: true)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
    
    
    @IBAction func registerAction(_ sender: UIButton){
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        self.performSegue(withIdentifier: "DangKi", sender: self)
    }
    
//--------------------//--------------------//--------------------//--------------------//--------------------
    
//    func loginCallBack(data: DataResponse<Any>){
//        print(data)
//        self.performSegue(withIdentifier: "loginSuccessSegue", sender: self)
//    }
//
//    func login_CallBack(error: String, isLoginSucess: Bool) {
//        if isLoginSucess {
//             self.performSegue(withIdentifier: "loginSuccessSegue", sender: self)
//        }else{
//            print("login failed")
//        }
//    }

//--------------------//--------------------//--------------------//--------------------//--------------------
    
    
    @IBAction func loginAction(_ sender: UIButton){
        Api.shared.login(email: userNameTextField.text!, password: passwordTextField.text!) { (error, isSuccess) in
            if isSuccess{
                UserDefaults.standard.set(self.userNameTextField.text!, forKey: EMAIL_KEY)
                UserDefaults.standard.set(self.passwordTextField.text!, forKey: PASSWORD_KEY)
                self.dismiss(animated: true, completion: nil)
            } else {
                self.thongBaoKetQua(mess: "Đăng nhập thất bại")
            }
        }
    }
    
    
    func thongBaoKetQua(mess: String){
        let alert: UIAlertController = UIAlertController(title: "Thông báo", message: mess, preferredStyle: .alert)
        let button_Ok: UIAlertAction = UIAlertAction(title: "OK", style: .default)
        alert.addAction(button_Ok)
        present(alert, animated: true, completion: nil)
    }
    

    @IBAction func closeLogin(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    
    
    
//    @IBAction func loginAction(_ sender: UIButton){
//        let url = "http://api.baongocstore.com/v1/auth/login"
//
//        let paramDict:[String: Any] = [
//            "email": userNameTextField!,
//            "password": passwordTextField!
//        ]
//        Alamofire.request(url, method: .post, parameters: paramDict, encoding: URLEncoding.default).response { (data) in
//            print(data)
//            if self.userNameTextField.text == "admin@example.com" && self.passwordTextField.text == "12345678"{
//                self.isLoginSucces = true
//                self.thongBaoKetQua(mess: "Đăng nhập thàng công")
//            }else{
//                self.isLoginSucces = false
//
//                self.thongBaoKetQua(mess: "Đăng nhập thất bại")
//            }
//        }
//    }
//
//    func comeToSegue(){
//        self.performSegue(withIdentifier: "loginSuccessSegue", sender: self)
//    }
//
    
}
