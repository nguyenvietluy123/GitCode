//
//  ViewController.swift
//  test
//
//  Created by Luy Nguyen on 5/3/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class ProfileVC: UIViewController {
    
    @IBOutlet weak var tabelView: UITableView!

    
    var profileCell = [(#imageLiteral(resourceName: "icon_heart"),"Tin rao yêu thích"), (#imageLiteral(resourceName: "icon_find"),"Tìm kiếm đã lưu"), (#imageLiteral(resourceName: "icon_friend"),"Bạn bè")]
    var profileItem = [(#imageLiteral(resourceName: "icon_coin"),"Đồng Tốt"),(#imageLiteral(resourceName: "icon_note"),"Lịch sử giao dịch"),(#imageLiteral(resourceName: "icon_plus"),"Tạo cửa hàng/Chuyên trang")]
    var profileGift = [(#imageLiteral(resourceName: "icon_gift"),"Rủ bạn & nhận quà"),(#imageLiteral(resourceName: "icon_gift"),"Nhập mã nhận thưởng")]
    var profileSystem = [(#imageLiteral(resourceName: "icon_help"),"Trợ giúp"),(#imageLiteral(resourceName: "icon_install"),"Cài đặt 😁")]
    override func viewDidLoad() {
        super.viewDidLoad()
        tabelView.dataSource = self
        tabelView.delegate = self

    }
    
    
}

extension ProfileVC: UITableViewDataSource,UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return profileCell.count
        case 1:
            return profileItem.count
        case 2:
            return profileGift.count
        default:
            return profileSystem.count
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0:
            let cell = tabelView.dequeueReusableCell(withIdentifier: "ProfileCell") as! ProfileCell
            let item = self.profileCell[indexPath.item]
            cell.setup(icon: item.0, name: item.1)
            return cell
        case 1:
            let cell = tabelView.dequeueReusableCell(withIdentifier: "ProfileCell2") as! ProfileCell2
            let item = self.profileItem[indexPath.item]
            cell.setup(item.0, item.1)
            return cell
        case 2:
            let cell = tabelView.dequeueReusableCell(withIdentifier: "ProfileCell3") as! ProfileCell3
            let item = self.profileGift[indexPath.item]
            cell.setup(icon:item.0,name: item.1)
            return cell
        default:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProfileCell4") as! ProfileCell4
            let item = profileSystem[indexPath.item]
            cell.setup(icon: item.0, name: item.1)
            return cell
            
        }
    }
}

