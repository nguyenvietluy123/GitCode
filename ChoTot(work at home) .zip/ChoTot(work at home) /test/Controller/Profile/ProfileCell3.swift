//
//  ProfileCell3.swift
//  test
//
//  Created by Luy Nguyen on 5/4/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class ProfileCell3: UITableViewCell {

    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var name: UILabel!
    
    func setup(icon: UIImage,name: String)
    {
        self.icon.image = icon
        self.name.text = name
    }

}
