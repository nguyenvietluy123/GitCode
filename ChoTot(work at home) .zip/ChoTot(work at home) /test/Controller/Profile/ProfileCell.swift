//
//  ProfileCell.swift
//  test
//
//  Created by Luy Nguyen on 5/3/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class ProfileCell: UITableViewCell {
    
    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var name: UILabel!
    
    func setup(icon: UIImage, name: String)
    {
        self.icon.image = icon
        self.name.text = name
        self.icon.layer.cornerRadius = self.icon.frame.size.height / 2
        self.icon.clipsToBounds = true
    }
}


