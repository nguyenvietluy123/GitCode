//
//  ProfileCell2.swift
//  test
//
//  Created by Luy Nguyen on 5/3/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class ProfileCell2: UITableViewCell {

    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var name: UILabel!
    
    func setup(_ icon: UIImage, _ name: String)
    {
        self.icon.image = icon
        self.name.text = name
    }

}
