//
//  StructAndClass.swift
//  test
//
//  Created by Luy Nguyen on 7/11/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import Foundation
import UIKit

struct Kind {
    var img : UIImage
    var title: String
    
    init(_ image: UIImage, _ lable: String) {
        img = image
        title = lable
    }
}
