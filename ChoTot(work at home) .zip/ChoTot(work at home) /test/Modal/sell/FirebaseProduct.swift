//
//  FirebaseProduct.swift
//  test
//
//  Created by Luy Nguyen on 6/24/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import Foundation
import Firebase
import FirebaseDatabase

struct FireBaseProduct {
    var image: String
    var title: String
    var price: Int
    var address: String
    var status: String
    
    init(_ snapshot: DataSnapshot) {
        let dataSnapshot = snapshot.value as! [String : AnyObject]
        self.image = dataSnapshot["image"] as! String
        self.title = dataSnapshot["title"] as! String
        self.price = dataSnapshot["price"] as! Int
        self.address = dataSnapshot["address"] as! String
        self.status = dataSnapshot["status"] as! String
    }
}
