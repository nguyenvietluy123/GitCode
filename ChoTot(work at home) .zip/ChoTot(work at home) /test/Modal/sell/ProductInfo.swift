//
//  ProductInfo.swift
//  test
//
//  Created by Luy Nguyen on 5/19/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import SwiftyJSON
import Firebase


class ProductInfo {
    var current_page: Int
    var data: [Product]
    
    init(_ json: JSON) {
        current_page = json["current_page"].intValue
        
        let array = json["data"].arrayValue
        data = [Product]()
        for item in array {
            data.append(Product(item))
        }
        data = json["data"].arrayValue.map({Product($0)})
//
//        var ref : DatabaseReference!
//        ref = Database.database().reference()
//        ref.child("data").observe(DataEventType.value) { (snap) in
//            data = snap.value
//        }
        
    }
    
    init() {
        current_page = 0
        data = []
    }
}


