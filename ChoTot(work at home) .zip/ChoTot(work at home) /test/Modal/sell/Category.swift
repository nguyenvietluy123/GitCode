//
//  Category.swift
//  test
//
//  Created by Luy Nguyen on 5/19/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import SwiftyJSON

struct Category {
    var id : Int
    var name: String
    var created_at: Date
    var updated_at: Date
    
    init(_ json: JSON) {
        id = json["id"].intValue
        name = json["name"].stringValue
        created_at = json["created_at"].stringValue.toDate()
        updated_at = json["updated_at"].stringValue.toDate()
    }
}


