//
//  MainVC.swift
//  ReadRSS
//
//  Created by Luy Nguyen on 7/23/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import Tabman
import Pageboy

class MainVC: TabmanViewController {

    var viewControllers = [UIViewController]()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.dataSource = self
        self.bar.items = [Item(title: "\(String(describing: typeNews!))"), Item(title: "Gần đây")]
        let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let newsVC = mainStoryboard.instantiateViewController(withIdentifier: "NewsVC")
        let healthyVC = mainStoryboard.instantiateViewController(withIdentifier: "HealthyVC")
        let entertainmentVC = mainStoryboard.instantiateViewController(withIdentifier: "EntertainmentVC")
        let recentsVC = mainStoryboard.instantiateViewController(withIdentifier: "RecentsVC")
        
        switch typeNews {
        case "Sức khoẻ":
            viewControllers.append(healthyVC)
        case "Giải trí":
            viewControllers.append(entertainmentVC)
        default:
            viewControllers.append(newsVC)
        }
        viewControllers.append(recentsVC)
        
        self.bar.appearance = TabmanBar.Appearance({ (Cnames) in
            Cnames.indicator.isProgressive = false
            Cnames.layout.edgeInset = 2
            Cnames.layout.minimumItemWidth = self.view.frame.size.width/2 - 12
            Cnames.indicator.color = #colorLiteral(red: 1, green: 0.8371937871, blue: 0.01217890903, alpha: 1)
        })
        
        self.reloadPages()
    }
}

extension MainVC: PageboyViewControllerDataSource {
    func numberOfViewControllers(in pageboyViewController: PageboyViewController) -> Int {
        return viewControllers.count
    }
    
    func viewController(for pageboyViewController: PageboyViewController, at index: PageboyViewController.PageIndex) -> UIViewController? {
        return viewControllers[index]
    }
        
    func defaultPage(for pageboyViewController: PageboyViewController) -> PageboyViewController.Page? {
        return nil
    }
}







