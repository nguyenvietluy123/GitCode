//
//  HealthyVC.swift
//  ReadRSS
//
//  Created by Luy Nguyen on 8/8/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import CoreData

class HealthyVC: UIViewController, XMLParserDelegate {
    @IBOutlet weak var tableView: UITableView!
    var refresher: UIRefreshControl!
    
    var passingData: Bool = true
    var performData: String = ""
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var displayItem = [Healthy]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.contentInset = UIEdgeInsets(top: 30, left: 0, bottom: 0, right: 0)
        refresher = UIRefreshControl()
        refresher.attributedTitle = NSAttributedString(string: "")
        //        refresher.addTarget(self, action: #selector(), for: UIControlEvents.valueChanged)
//        tableView.addSubview(refresher)
        
        tableView.estimatedRowHeight = 150
        tableView.rowHeight = UITableViewAutomaticDimension
        
        var parser: XMLParser? = XMLParser()
        let url: URL = URL(string: "http://dantri.com.vn/suc-khoe.rss")!
        parser = XMLParser(contentsOf: url as URL)!
        parser?.delegate = self
        parser?.parse()
        
        fetchData()
        
        for i in 0...9 {
            displayItem.append(items[i])
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segue"{
            let webVC = segue.destination as! WebVC
            webVC.data = performData
        }
    }
    
    var items = [Healthy]()
    var items1 = [Healthy]()
    var item = Item()
    var foundCharacters = ""
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        if (elementName == "item") {
            passingData = true
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        if passingData{
            self.foundCharacters = string
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "title"{
            self.item.title = self.foundCharacters
        }
        if elementName == "description"{
            self.item.desc = getUrlImage(self.foundCharacters)
        }
        if elementName == "link"{
            self.item.link = self.foundCharacters
        }
        if elementName == "pubDate"{
            self.item.pudDate = self.foundCharacters
        }
        if elementName == "item" {
            let tempItem = Healthy(context: context)
            tempItem.title = self.item.title
            
            if self.item.desc != "not found"{
                tempItem.desc = self.item.desc
            }
            tempItem.link = self.item.link
            tempItem.pudDate = self.item.pudDate
            self.items1.append(tempItem)
            passingData = false
            
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
        }
        self.foundCharacters = ""
    }
    
    //    func parserDidEndDocument(_ parser: XMLParser) {
    //        for item in self.items {
    //            print("\(item.title),\(item.link),\(item.pudDate)")
    //        }
    //    }
    
    var containTitleArray: [String] = []
    func fetchData() {
        do {
            let products = try context.fetch(Healthy.fetchRequest()) as! [Healthy]
            items1.append(contentsOf: products)
            
            for product in items1 {
                if product.title != nil {
                    containTitleArray.append(product.title!)
                }
            }
            containTitleArray.removeDuplicates()
            
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Healthy")
            for char in containTitleArray{
                request.predicate = NSPredicate(format: "title CONTAINS %@", char)
                request.returnsObjectsAsFaults = false
                
                let info = try context.fetch(request) as! [Healthy]
                guard !info.isEmpty else { return }
                items.append(info[0])
            }
            //            SaveCoreData()
        }catch let err {
            print("loading error", err)
        }
    }
    
    func SaveCoreData(){
        do{
            let pro = try context.fetch(Healthy.fetchRequest()) as! [Healthy]
            for char in pro {
                context.delete(char)
                
            }
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            
        }catch{}
    }
    
    func getUrlImage(_ descString: String ) -> String {
        let desc = descString
        let startSubstring = "img src=\""
        var index = 0
        for char in desc.description {
            if startSubstring.description.first == char {
                let startOfFoundCharacter = desc.index(desc.startIndex, offsetBy: index)
                let lengthOfFoundCharacter = desc.index(desc.startIndex, offsetBy: (startSubstring.description.count + index))
                let range = startOfFoundCharacter..<lengthOfFoundCharacter
                //                print(desc.substring(with: range))
                if desc[range] == startSubstring {
                    //                    print("Found: \(startSubstring)")
                    let startofFound = desc.index(desc.startIndex, offsetBy: index + startSubstring.description.count)
                    let endOfFound = desc.index(desc.endIndex, offsetBy: -8)
                    let range2 = startofFound..<endOfFound
                    
                    return String(desc[range2])
                }
            }
            index += 1
        }
        return "not found"
    }
    
    
}

