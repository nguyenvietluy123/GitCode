//
//  EntertainmentVC+Datasource+Delegate.swift
//  ReadRSS
//
//  Created by Luy Nguyen on 8/10/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import Foundation
import UIKit

extension EntertainmentVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //        if section == 0 {
        //            return 1
        //        }
        guard !displayItem.isEmpty else {
            return items.count
        }
        return displayItem.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EntertainmentCell") as? EntertainmentCell
        //        if indexPath.section == 0 {
        guard !displayItem.isEmpty else {
            cell?.setup(items[indexPath.item])
            return cell!
        }
        cell?.setup(displayItem[indexPath.item])
        
        //        }
        //        if indexPath.section == 1 {
        //            cell?.setup(displayItem[indexPath.item])
        //        }
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performData = items[indexPath.item].link!
        self.performSegue(withIdentifier: "segue", sender: nil)
        let webVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "WebVC") as! WebVC
        webVC.data = items[indexPath.item].link!
        
        let newItem = Products(context: context)
        newItem.title = items[indexPath.item].title
        newItem.desc = items[indexPath.item].desc
        newItem.link = items[indexPath.item].link
        newItem.pudDate = items[indexPath.item].pudDate
        
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == displayItem.count - 1 {
            if displayItem.count < items.count {
                
                let spinner = UIActivityIndicatorView(activityIndicatorStyle: .gray)
                spinner.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
                spinner.startAnimating()
                tableView.tableFooterView = spinner
                Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { (timee) in
                    spinner.stopAnimating()
                }
                
                self.perform(#selector(fetch), with: nil, afterDelay: 1.0)
                
                
            }
        }
    }
    
    @objc func fetch() {
        var index = displayItem.count
        let limit = index + 5
        
        repeat {
            displayItem.append(items[index])
            index += 1
            if index == limit {
                break
            }
            
        }while index < items.count
        self.tableView.reloadData()
    }
}

