//
//  HealthyCell.swift
//  ReadRSS
//
//  Created by Luy Nguyen on 8/8/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import SDWebImage

class HealthyCell: UITableViewCell {
    @IBOutlet weak var titleLable: UILabel!
    @IBOutlet weak var linkLable: UILabel!
    @IBOutlet weak var pubdateLable: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var statusView: UIImageView!
    func setup(_ item: Healthy){
        titleLable.text = item.title
        
        guard item.desc != nil else {
            return
        }
        imgView.sd_setImage(with: URL(string: item.desc!), completed: nil)
        
        linkLable.text = item.link
        pubdateLable.text = item.pudDate
    }
    
}
