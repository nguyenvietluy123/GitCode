//
//  Cell.swift
//  ReadRSS
//
//  Created by Luy Nguyen on 8/7/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

class Cell: UITableViewCell {
    
    @IBOutlet weak var title: UILabel!
    


}
