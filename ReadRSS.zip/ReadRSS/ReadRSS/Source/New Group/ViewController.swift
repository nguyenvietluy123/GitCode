//
//  ViewController.swift
//  ReadRSS
//
//  Created by Luy Nguyen on 8/7/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit

var typeNews: String? = "Xã hội"

class ViewController: UIViewController {
    @IBOutlet weak var containView: UIView!
    @IBOutlet weak var viewForNews: UIView!
    @IBOutlet weak var leftContainView: NSLayoutConstraint!
    @IBOutlet weak var tableView: UITableView!
    
    var item: [String] = ["Sức khoẻ", "Xã hội", "Giải trí"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    var open: Bool = false
    @IBAction func Category(_ sender: Any) {
        //        self.view.translatesAutoresizingMaskIntoConstraints = false
        if open {
            UIView.animate(withDuration: 0.5) {
                self.containView.transform = self.containView.transform.translatedBy(x: -self.view.frame.width/2, y: 0)
            }
        }else{
            UIView.animate(withDuration: 0.5) {
                self.containView.transform = self.containView.transform.translatedBy(x: self.view.frame.width/2, y: 0)
            }
        }
        open = !open
    }
    
    @IBOutlet weak var btnListOfCategory: UIButton!
    @IBAction func btn_ListOfCategory(_ sender: Any) {
        if btnListOfCategory.imageView?.image == UIImage(named: "down") {
            btnListOfCategory.setImage(#imageLiteral(resourceName: "up"), for: .normal)
        } else {
            btnListOfCategory.setImage(#imageLiteral(resourceName: "down"), for: .normal)
        }
    }
    
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return item.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! Cell
        cell.title.text = item[indexPath.item]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 55
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        typeNews = item[indexPath.item]
        
        let mainVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MainVC") as! MainVC
        viewForNews.addSubview(mainVC.view)
        addChildViewController(mainVC)
        mainVC.didMove(toParentViewController: self)
        mainVC.reloadPages()
        
        UIView.animate(withDuration: 0.5) {
            self.containView.transform = self.containView.transform.translatedBy(x: -self.view.frame.width/2, y: 0)
            self.open = !self.open
        }
    }
    
    
    
}
