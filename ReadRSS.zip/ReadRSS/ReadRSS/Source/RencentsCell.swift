//
//  RencentsCell.swift
//  ReadRSS
//
//  Created by Luy Nguyen on 7/23/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import SDWebImage

class RencentsCell: UITableViewCell {
    @IBOutlet weak var titleLable: UILabel!
    @IBOutlet weak var linkLable: UILabel!
    @IBOutlet weak var pubdateLable: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    
    func setup(_ item: Products){
        titleLable.text = item.title

        if let img = item.desc {
            imgView.sd_setImage(with: URL(string: img), completed: nil)
        }
//        imgView.contentMode = .scaleAspectFit
//        imgView.layer.masksToBounds = true
        
        linkLable.text = item.link
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "EEE, dd-MM-yyyy HH:mm:ss zzz"
        
        let dateFormatterPrint = DateFormatter()
        dateFormatterPrint.dateFormat = "MMM dd,yyyy"
        
        if let date = dateFormatterGet.date(from: item.pudDate!){
            pubdateLable.text = dateFormatterPrint.string(from: date)
        }
        else {
            print("There was an error decoding the string")
        }
    }
    
}
