//
//  WebVC.swift
//  ReadRSS
//
//  Created by Luy Nguyen on 7/19/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import WebKit

class WebVC: UIViewController {
    @IBOutlet weak var webView: WKWebView!
    var data: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        let url: URL = URL(string: data)!
        let request: URLRequest = URLRequest(url: url)
        webView.load(request)
    }

    
    @IBAction func buttonBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
