//
//  RecentsVC.swift
//  ReadRSS
//
//  Created by Luy Nguyen on 7/23/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import UIKit
import CoreData

class RecentsVC: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    var performData: String = ""
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var products = [Products]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.contentInset = UIEdgeInsets(top: 30, left: 0, bottom: 0, right: 0)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segue"{
            let webVC = segue.destination as! WebVC
            webVC.data = performData
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        fetch_Data()
        tableView.reloadData()
    }

    var containArray = [String]()
    func fetch_Data() {
        do {
            let items = try context.fetch(Products.fetchRequest()) as! [Products]
            for item in items {
                containArray.insert(item.title!, at: 0)
            }
            containArray.removeDuplicates()
            
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Products")
            
            products.removeAll()
            for char in containArray {
                request.predicate = NSPredicate(format: "title CONTAINS %@", char)
                request.returnsObjectsAsFaults = false
                var info = try context.fetch(request) as! [Products]
                products.append(info[0])
            }
            

//                for char in items{
//                    context.delete(char)
//                    (UIApplication.shared.delegate as! AppDelegate).saveContext()
//                }

        }
        catch let error{
            print("Fetch error!", error)
        }

//        if products.count > 0 {
//            for i in 0..<products.count {
//                let x = i + 1
//                for x in x..<products.count{
//                    if products[i].title == products[x].title {
//                        print("equal")
//                    }
//                }
//            }
//        }
    }
    
    

}

extension RecentsVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RencentsCell") as? RencentsCell
        cell?.setup(products[indexPath.item])
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performData = products[indexPath.item].link!
        self.performSegue(withIdentifier: "segue", sender: nil)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
//    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
//        let delete = UITableViewRowAction(style: .default, title: "delete") { (action, indexpath) in
//            let item = self.products[indexPath.item]
//            self.context.delete(item)
//            (UIApplication.shared.delegate as! AppDelegate).saveContext()
//
//            tableView.beginUpdates()
//            self.products.remove(at: indexPath.item)
//            tableView.deleteRows(at: [indexPath], with: .automatic)
//            tableView.endUpdates()
//        }
//        return [delete]
//    }
//

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            products.remove(at: indexPath.item)
            let item = products[indexPath.item]
            
            self.context.delete(item)
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            
            tableView.beginUpdates()
            tableView.deleteRows(at: [indexPath], with: .automatic)
            tableView.endUpdates()
        }
    }
    
    
}






