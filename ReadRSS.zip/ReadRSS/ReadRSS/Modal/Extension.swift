//
//  Extension.swift
//  ReadRSS
//
//  Created by Luy Nguyen on 7/27/18.
//  Copyright © 2018 Luy Nguyen. All rights reserved.
//

import Foundation

extension Array where Element: Equatable {
    mutating func removeDuplicates() {
        var result = [Element]()
        for value in self {
            if !result.contains(value) {
                result.append(value)
            }
        }
        self = result
    }
}

class Item {
    var title = ""
    var desc = ""
    var link = ""
    var pudDate = ""
    var status: Bool = false
}


